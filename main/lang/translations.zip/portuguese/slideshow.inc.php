<?php
/*
for more information: see languages.txt in the lang folder.
*/
$lang_height = "Altura";
$lang_resizing_comment = "redimensionar imagem para as seguintes dimensões (em pixels)";
$lang_width = "Largura";
$lang_resizing = "REDIMENSIONAR";
$lang_no_resizing_comment = "Mostrar as imagens na sua dimensão original. Naõ foi realizado nenhum redimensionamento. As barras de scroll surgirão automaticamente se a largura da imagem for superior à dimensão do ecrã do seu monitor.";
$lang_show_thumbnails = "Apresentar miniaturas";
$lang_click_thumbnails = "Clicar numa das miniaturas";
$lang_set_slideshow_options = "Configurações da Galeria";
$lang_slideshow_options = "Opções da Apresentação de slides";
$lang_no_resizing = "NENHUM REDIMENSIONAMENTO (pré-definido)";
$lang_exit_slideshow = "Sair da Apresentação de slides";
$SlideShow = "Apresentação de slides";
$lang_previous_slide = "Slide anterior";
$lang_next_slide = "Imagem seguinte";
$lang_image = "Imagem";
$lang_of = "de";
$lang_view_slideshow = "Ver Apresentação de slides";
$FirstSlide = "Primeiro slide/diapositivo";
$LastSlide = "Último slide/diapositivo";
?>