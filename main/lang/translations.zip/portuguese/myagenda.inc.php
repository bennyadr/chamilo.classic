<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langMyAgenda = "Agenda pessoal";
$langToday = "Hoje";
?>