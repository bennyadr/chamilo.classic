<?php
/*
for more information: see languages.txt in the lang folder.
*/
$select = "Validar";
$square = "Quadrado";
$circle = "Elipse";
$poly = "Polígono";
$status1 = "Desenhe um hotspot (área clicável).";
$status2_poly = "Utilize o botão direito do rato para fechar o polígono.";
$status2_other = "Libertar o botão do rato para guardar o hotspot (área clicável).";
$status3 = "Hotspot (área clicável) guardado";
$exercise_status_1 = "Responda clicando na imagem abaixo";
$exercise_status_2 = "Validar respostas";
$exercise_status_3 = "Estado: Pergunta encerrada";
$showUserPoints = "Mostrar/Esconder cliques do utilizador";
$showHotspots = "Mostrar / Esconder hotspots (áreas clicáveis)";
$labelPolyMenu = "Fechar polígono";
$triesleft = "Tentativas restantes";
$exeFinished = "Clique no botão abaixo para validar as suas respostas.";
$nextAnswer = "Clique agora em: &done=done";
$delineation = "Delimitação";
$labelDelineationMenu = "Fechar delimitação";
$oar = "Área em risco";
?>