<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langTool = "Metadados";
$langClickKw = "Clique numa palavra-chave da árvore para seleccionar ou desceleccionar.";
$langKwHelp = "<br/> Clique no botão \'+\' para abrir, no botão \'-\' para fechar, no botão \'++\' para abrir todos, no botão \'--\' para fechar todos.<br/> <br/> Elimine todas as palavras-chave seleccionadas fechando a árvore e abrindo-a novamente com o botão \'+\'.<br";
$langAdvanced = "Avançado";
$langSearch = "Pesquisa";
$langSearchCrit = "Utilize a área abaixo para palavras descritivas, uma palavra por linha!";
$langNoKeywords = "Este curso não tem palavras-chave";
$langKwCacheProblem = "A palavra-chave não pode ser aberta";
$langCourseKwds = "palavras-chave do curso";
$langKwdsInMD = "palavras-chave usadas no MD";
$langKwdRefs = "referências das palavras-chave";
$langNonCourseKwds = "Non-course keywords";
$langKwdsUse = "Palavras-chave do curso (negrito = não usada)";
$langTotalMDEs = "Número total de entradas MD:";
?>