<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langClarContent = "<p><b>Instrutor</b></p><p>O Chamilo é uma plataforma/sistema de Gestão do Conhecimento e da Aprendizagem. Permite a um instrutor organizar e gerir cursos, materiais didáticos e interagir com os utilizadores. Toda esta getão é realizada através num ambient";
$test = "Teste/exercício";
$WCAGImage = "Imagem";
$WCAGLabel = "Identificação/legenda da imagem";
$WCAGLink = "Ligação/link";
$WCAGLinkLabel = "Identificação/legenda da ligação";
$errorNoLabel = "Imagem sem legenda/identificação.";
$AllLanguages = "todos os idiomas";
$WCAGEditor = "Editor WCAG";
$WCAGGoMenu = "Ir para o menu";
$WCAGGoContent = "Ir para os conteúdos";
?>