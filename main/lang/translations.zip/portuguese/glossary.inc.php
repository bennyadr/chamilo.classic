<?php
/*
for more information: see languages.txt in the lang folder.
*/
$TermAddNew = "Adicionar novo termo ao glossário";
$TermName = "Termo";
$TermDefinition = "Definição do termo";
$TermDeleted = "Termo removido";
$TermUpdated = "Termo actualizado";
$TermConfirmDelete = "Deseja mesmo eliminar este termo?";
$TermAddButton = "Guardar termo";
$TermUpdateButton = "Actualizar termo";
$TermEdit = "Editar termo";
$TermDeleteAction = "Eliminar termo";
$OrderBy = "Ordenar por";
$CreationDate = "Data de criação";
$UpdateDate = "Actualizado";
$PreSelectedOrder = "Pré-definido";
$TermAdded = "Termo adicionado";
$YouMustEnterATermName = "Tem de introduzir um termo";
$YouMustEnterATermDefinition = "Tem de introduzir a definição de um termo";
$TableView = "Visualizar tabela";
$GlossaryTermAlreadyExistsYouShouldEditIt = "Este termo do glossário já existe. Por favor modifique o nome do termo.";
$GlossaryManagement = "Gestão do glossário";
$TermMoved = "O termo foi movido";
$ShowGlossaryInExtraToolsTitle = "Apresentar o glossário de termos nas ferramentas extra";
$ShowGlossaryInExtraToolsComment = "Neste local pode configurar como adicionar o glossário de termos nas ferramentas extras como um percurso/caminho de aprendizagem e ferramenta de exercício";
?>