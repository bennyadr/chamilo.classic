<?php
/*
for more information: see languages.txt in the lang folder.
*/
$lang_new_item = "novo item adicionado";
$lang_title_notification = "Desde a última visita";
$lang_update_agenda = "evento actualizado";
$lang_new_agenda = "evento adicionado";
$lang_update_announcements = "actualizado o anúncio existente";
$lang_new_announcements = "novo anúncio adicionado";
$lang_new_document = "novo(s) documentos(s) adicionado";
$lang_new_exercise = "novo exercício activado";
$lang_update_link = "actualizada a ligação/link existente";
$lang_new_link = "nova ligação/link adicionada";
$lang_new_forum_topic = "novo tópico adicionado";
$lang_new_groupforum_topic = "novo tópico adicionado ao grupo do fórum";
$lang_new_dropbox_file = "novo ficheiro recebido";
$lang_update_dropbox_file = "um ficheiro na caixa de entrega foi actualizado";
$ForumCategoryAdded = "Categoria fórum adicionada";
$LearnpathAdded = "Curso adicionado";
$GlossaryAdded = "Adicionado um novo termo ao Glossário";
$QuizQuestionAdded = "Adicionada uma nova pergunta ao questionário";
$QuizQuestionUpdated = "Actualizada a nova pergunta no Questionário";
$QuizQuestionDeleted = "Eliminada a nova pergunta no Questionário";
$QuizUpdated = "Questionário actualizado";
$QuizAdded = "Questionário adicionado";
$QuizDeleted = "Questionário eliminado";
$DocumentInvisible = "Documento invisível";
$DocumentVisible = "Documento visível";
$CourseDescriptionAdded = "Descrição do curso adicionada";
$WikiAdded = "Wiki adicionado";
$SurveyAdded = "Inquérito adicionado";
$NotebookAdded = "Nota adicionada";
$NotebookUpdated = "Nota actualizada";
$NotebookDeleted = "Nota eliminada";
?>