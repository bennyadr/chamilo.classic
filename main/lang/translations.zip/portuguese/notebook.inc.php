<?php
/*
for more information: see languages.txt in the lang folder.
*/
$NewNote = "Nova nota";
$Note = "Nota";
$NoteDeleted = "Nota eliminada";
$NoteUpdated = "Nota actualizada";
$NoteCreated = "Nota criada";
$YouMustWriteANote = "Por favor escrever uma nota.";
$SaveNote = "Guardar nota";
$WriteYourNoteHere = "Cliique aqui para escrever uma nova nota";
$SearchByTitle = "Pesquisar por título";
$WriteTheTitleHere = "Escreva aqui o título";
$UpdateDate = "Última modificação";
$NoteAddNew = "Adicionar uma nova nota no meus bloco de notas pessoal";
$OrderByCreationDate = "Ordenar por data de criação";
$OrderByModificationDate = "Ordenar por data da última modificação";
$OrderByTitle = "Ordenar por título";
$NoteTitle = "Título da nota";
$NoteComment = "Detalhes da nota";
$NoteAdded = "Nota acrescentada";
$NoteConfirmDelete = "Tema certeza que deseja eliminar esta nota";
$AddNote = "Criar nota";
$ModifyNote = "Editar a minha nota pessoal";
$BackToNoteList = "Voltar à lista das notas";
$NotebookManagement = "Gestão do bloco de notas";
$BackToNotesList = "Regressar à lista das notas";
$NotesSortedByTitleAsc = "Notas ordenadas de forma ascendente pelo título";
$NotesSortedByTitleDESC = "Notas ordenadas de forma descendente pelo título";
$NotesSortedByUpdateDateAsc = "Notas ordenadas de forma ascendente pela data de actualização";
$NotesSortedByUpdateDateDESC = "Notas ordenadas de forma descendente pela data de actualização";
$NotesSortedByCreationDateAsc = "Notas ordenadas de forma ascendente pela data de criação";
$NotesSortedByCreationDateDESC = "Notas ordenadas de forma descendente pela data de criação";
?>