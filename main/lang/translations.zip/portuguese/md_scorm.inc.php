<?php
/*
for more information: see languages.txt in the lang folder.
*/
$nameTools = "var de idioma obsoleta";
$langMdCallingTool = "Curso";
$langTool = "Operações Scorm MD";
$langNotInDB = "Não existe entrada DB Chamilo";
$langManifestSyntax = "(erro de sintaxe no ficheiro manifest ...)";
$langEmptyManifest = "(esvaziar ficheiro manifest ...)";
$langNoManifest = "(não existe ficheiro manifest ...)";
$langNotFolder = "não é possível, não é uma pasta/directório ...";
$langUploadHtt = "Enviar ficheiro HTT";
$langHttFileNotFound = "Não foi possível abrir o novo HTT (p.ex.: vazio, demasiado grande)";
$langHttOk = "O novo ficheiro HTT foi enviado";
$langHttNotOk = "falhou a transferência do ficheiro HTT";
$langRemoveHtt = "Remover o ficheiro HTT";
$langHttRmvOk = "O ficheiro HTT foi removido";
$langHttRmvNotOk = "A remoção do ficheiro HTT falhou";
$langImport = "Criar MDEs a partir do manifest";
$langRemove = "Remover MDEs";
$langAllRemovedFor = "Todas as entradas foram removidas para";
$langIndex = "Indexar palavras com o PhpDig";
$langTotalMDEs = "Número total de entradas Scorm MD:";
$langMainMD = "Abrir MDE Principal";
$langLines = "linhas";
$langPlay = "Executar index.php";
$langNonePossible = "Não são possíveis operações MD";
$langOrElse = "Seleccionar uma Directoria/pasta Scorm ou o id de uma Directoria/pasta Scorm";
$langWorkWith = "Trabalhar com a Directoría/pasta Scorm";
$langSDI = "... Directoría/pasta Scorm com o SD-id (e dividir o manifest - ou deixar vazio)";
$langRoot = "raiz";
$langSplitData = "Dividir manifests, e #MDe, se houver:";
$langMffNotOk = "A substituição do ficheiro manifest falhou";
$langMffOk = "O ficheiro manifest foi substituido";
$langMffFileNotFound = "Não foi possível abrir o novo ficheiro manifest (p.ex.: vazio, demasiado grande)";
$langUploadMff = "Substituir o ficheiro manifest";
?>