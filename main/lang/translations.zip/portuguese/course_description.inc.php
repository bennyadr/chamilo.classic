<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langCourseProgram = "Descrição";
$langThisCourseDescriptionIsEmpty = "Ainda existe qualquer descrição do curso.";
$langEditCourseProgram = "Criar ou editar uma descrição.";
$QuestionPlan = "Ajuda";
$langInfo2Say = "Informação a comunicar aos utilizadores";
$langOuAutreTitre = "Título";
$langNewBloc = "Outro";
$langAddCat = "Adicionar uma categoria";
$langAdd = "Adicionar";
$langValid = "Validar";
$langBackAndForget = "Cancelar";
$CourseDescriptionUpdated = "A descrição foi actualizada";
$CourseDescriptionDeleted = "A descrição do curso foi apagada";
$CourseDescriptionIntro = "Para criar uma descrição, clique na rubrica e preencha o campo associado.<br><br>Clique OK para continuar.";
$langSaveDescription = "Guardar descrição";
?>