<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langActivate = "Prikaži";
$langDeactivate = "Skrij";
$langInLnk = "Skrita orodja in povezave";
$langDelLk = "Ali res želiš odstraniti to povezavo?";
$langCourseCreate = "Tvori spletno stran tečaja";
$langNameOfTheLink = "Ime povezave";
$lang_main_categories_list = "Seznam glavnih kategorij";
$langCourseAdminOnly = "Le učitelji";
$PlatformAdminOnly = "Le upravitelji platforme";
$langCombinedCourse = "Združeni tečaji";
$ToolIsNowVisible = "Orodje je sedaj vidno";
$ToolIsNowHidden = "Orodje je sedaj nevidno";
$EditLink = "Uredi povezavo";
$Blog_management = "Upravljanje blogov";
$Forum = "Forumi";
$Course_maintenance = "Upravljanje tečajev";
$TOOL_SURVEY = "Evalvacijski vprašalniki";
$GreyIcons = "Orodjarna";
$Interaction = "Interakcijska orodja";
$Authoring = "Avtorska orodja";
$Administration = "Upravljanje";
$IntroductionTextUpdated = "Uvodno besedilo je bilo ažurirano";
$IntroductionTextDeleted = "Uvodno besedilo je bilo odstranjeno";
$SessionIdentifier = "Identifikator seje";
$SessionName = "Ime seje";
$SessionCategory = "Kategorija seje";
$SessionData = "Podatki seje";
?>