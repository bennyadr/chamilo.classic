<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langPgTitle = "Naslov strani";
$langExplanation = "Stran mora biti v obliki HTML(na pr. \\"moja_stran.htm\\"). Povezana bo z domače strani. Če želiš poslati več dokumentov, ki niso HTML (PDF, Word, Power Point, Video,...) uporabi orodje <a href=../document/document.php>dokumenti</a>";
$langTooBig = "Nisi izbral nobene datoteke za prenos, ali pa je ta prevelika";
$langCouldNot = "Datoteke nisem mogel prenesti";
$langNotAllowed = "Ni dovoljeno";
$langAddPageToSite = "Dodaj stran na spletno lokacijo";
$langCouldNotSendPage = "Ta datoteka ni v HTML obliki in ne more biti prenešena. Če želite prenesti datoteko, ki ni v HTML obliki (PDF, Word, Power Point, Video, ...) uporabite orodje <a href=../document/document.php>dokumenti</a>";
$langSendPage = "Stran za prenos (upload)";
$langPageTitleModified = "Naslov strani je bil spremenjen";
$langPageAdded = "Stran je dodana";
$langAddPage = "Dodaj stran";
$Choose = "Razišči";
?>