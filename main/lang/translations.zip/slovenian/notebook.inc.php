<?php
/*
for more information: see languages.txt in the lang folder.
*/
$NewNote = "Nova beležka";
$Note = "Beležka";
$NoteDeleted = "Beležka je bila odstranjena";
$NoteUpdated = "Beležka je bila ažurirana";
$NoteCreated = "Beležka je bila ustvarjena";
$YouMustWriteANote = "Prosim, dodajte zapis v beležko";
$SaveNote = "Shrani beležko";
$WriteYourNoteHere = "Tule zapišite svojo beležko";
$SearchByTitle = "Išči po naslovu";
$WriteTheTitleHere = "Tule dodaj naslov";
$UpdateDate = "Zadnja sprememba";
$NoteAddNew = "Dodaj novo";
$OrderByCreationDate = "Po datumu nastanka";
$OrderByModificationDate = "Po datumu spremembe";
$OrderByTitle = "Po naslovu";
$NoteTitle = "Naslov beležke";
$NoteComment = "Podrobnosti beležke";
$NoteAdded = "Beležka je bila dodana";
$NoteConfirmDelete = "Ste prepričani, da želite odstraniti beležko?";
$AddNote = "Dodaj beležko";
$ModifyNote = "Spremeni beležko";
$BackToNoteList = "Nazaj na seznam beležk";
$NotebookManagement = "Upravljanje beležk";
$BackToNotesList = "Nazaj na seznam beležk";
$NotesSortedByTitleAsc = "Po naslovu naraščajoče";
$NotesSortedByTitleDESC = "Po naslovu padajoče";
$NotesSortedByUpdateDateAsc = "Po datumu ažuriranja naraščajoče";
$NotesSortedByUpdateDateDESC = "Po datumu ažuriranja padajoče";
$NotesSortedByCreationDateAsc = "Po datumu nastanka naraščajoče";
$NotesSortedByCreationDateDESC = "Po datumu nastanka padajoče";
?>