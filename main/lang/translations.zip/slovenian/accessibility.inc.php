<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langClarContent = "<p><b>Učitelj</b></p><p>Dokeos je sistem za upravljanje z učenjem in znanjem (LMS - Learning Management System in KMS -Knowledge Management System). Omogoča učiteljem organizirati učno snov, učne poti in upravljati interakcije s svojimi tečajniki. Vse to/";
$test = "test";
$WCAGImage = "slika";
$WCAGLabel = "oznaka slike";
$WCAGLink = "povezava";
$WCAGLinkLabel = "oznaka povezave";
$errorNoLabel = "Slika je brez oznake.";
$AllLanguages = "vsi jeziki";
$WCAGEditor = "WCAG Urejevalnik";
$WCAGGoMenu = "Pojdi na izbiro";
$WCAGGoContent = "Pojdi na vsebino";
?>