<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langViewCourseMaterialImport = "Poglej material tečaja kot bo uvožen";
$langViewExternalLinksImport = "Poglej zunanje povezave, kot bodo uvožene";
$langViewForumImport = "Poglej forum, kot bo uvožen";
$langImportCourseMaterial = "Uvozi material tečaja (Blackboard orodje \\"Material tečaja\\")";
$langImportExternalLinks = "Uvozi povezave (Blackboard orodje \\"Zunanje povezave\\")";
$langImportForum = "Uvozi forume (Blackboard orodje \\"Razprave\\")";
$langToolInfo = "To orodje je namenjeno uvozu tečajev Blackboard 5.5 (Material tečaja, razprave, in zunanje povezave).";
$langToolName = "Uvoz tečajev Blackboard";
$langSelectCoursePackage = "Izberi tečaj";
$langPackageAlreadySelected = "Tečaj je že izbran";
$langFirstSelectPackage = "Najprej je potrebno izbrati tečaj in ga odpreti predenj nadaljujete z izvozom.";
$langCourseToMigrate = "Tečaj za pretvorbo";
$langSelectPackage = "Izberite tečaj";
$langOpenPackageForImporting = "Odpri ta tečaj za uvoz";
$langInformation = "Informacije o procesu uvoza";
$langChooseImportOptions = "Izberite možnosti uvoza";
$langCheckWhatIsImported = "Preverite lahko, kaj se bo uvozilo, predenj se dejansko prične postopek uvoza";
$langStartImporting = "Pričenjam uvažati";
$langImport = "Uvoz";
?>