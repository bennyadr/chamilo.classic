<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langCourseProgram = "Opis tečaja";
$langThisCourseDescriptionIsEmpty = "Ta tečaj še ni opisan";
$langEditCourseProgram = "Tvori in uredi opis tečaja";
$QuestionPlan = "Vprašanja za učitelja";
$langInfo2Say = "Informacija za tečajnike";
$langOuAutreTitre = "Naziv";
$langNewBloc = "Drugo";
$langAddCat = "Dodaj kategorijo";
$langAdd = "Dodaj";
$langValid = "Uveljavi";
$langBackAndForget = "Prekliči";
$CourseDescriptionUpdated = "Opis tečaja je bil ažuriran";
$CourseDescriptionDeleted = "Opis tečaja je bil odstranjen";
$CourseDescriptionIntro = "Da bi opisali tečaj, kliknite na ustrezen naslov in vnesite želene podatke v vnosna polja.<br /><br />Zaključite s klikom na OK, nato ponovite za naslednji želen naslov.";
$langSaveDescription = "Shrani opis";
?>