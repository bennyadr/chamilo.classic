<?php
/*
for more information: see languages.txt in the lang folder.
*/
$lang_new_item = "nov element dodan";
$lang_title_notification = "Od vašega zadnjega obiska";
$lang_update_agenda = "obstoječ element agende ažuriran";
$lang_new_agenda = "nov element agende dodan";
$lang_update_announcements = "obstoječe obvestilo ažurirano";
$lang_new_announcements = "novo obvestilo dodano";
$lang_new_document = "nov dokument(dokumenti) dodan dodani)";
$lang_new_exercise = "nova vaja omogočena";
$lang_update_link = "informacija o obstoeči povezavi ažurirana";
$lang_new_link = "nova povezava dodana";
$lang_new_forum_topic = "nova tema dodana";
$lang_new_groupforum_topic = "nova tema dodana v forum skupine";
$lang_new_dropbox_file = "prejeta nova datoteka";
$lang_update_dropbox_file = "datoteka v vašem nabiralniku je bila ažurirana";
$ForumCategoryAdded = "Kategorija foruma je bila dodana";
$LearnpathAdded = "Učna pot je bila dodana";
$GlossaryAdded = "V besednjak je bil dodan nov termin.";
$QuizQuestionAdded = "Novo vprašanje je bilo dodano";
$QuizQuestionUpdated = "Vprašanje je bilo ažurirano";
$QuizQuestionDeleted = "Vprašanje je bilo odstranjeno";
$QuizUpdated = "Test je bil ažuriran";
$QuizAdded = "Test je bil dodan";
$QuizDeleted = "Test je bil odstranjen";
$DocumentInvisible = "Dokument je skrit";
$DocumentVisible = "Dokument je viden";
$CourseDescriptionAdded = "Opis tečaja je bil dodan";
$WikiAdded = "Wiki je bil dodan";
$SurveyAdded = "Vprašalnik je bil dodan";
$NotebookAdded = "Beležka je bila dodana";
$NotebookUpdated = "Beležka je bila ažurirana";
$NotebookDeleted = "Beležka je bila odstranjena";
?>