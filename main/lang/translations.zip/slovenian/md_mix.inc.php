<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langTool = "Metapodatki";
$langClickKw = "Za izbiro ali preklic izbire, klikni na ključno besedo v drevesu.";
$langKwHelp = "<br/> Klik na \'+\' za odpiranje, \'-\' za zapiranje, \'++\' odpre vse, \'--\' zapre vse.<br/> <br/> Počisti izbrane ključne besede s tem, da zaprete drevo in ga ponovno odprete s \'+\' .<br/> Alt-klik \'+\' poišče originalne kljune besede v drevesu.<br/>";
$langAdvanced = "Napredno";
$langSearch = "Iskanje";
$langSearchCrit = "Le ena beseda na vrstico!";
$langNoKeywords = "Ta tečaj ne vsebuje nobenih ključnih besed";
$langKwCacheProblem = "Medpomnilnika ključnih besed ni mogoče odpreti";
$langCourseKwds = "ključne besede tečaja";
$langKwdsInMD = "ključne besede uporabljene v MD";
$langKwdRefs = "reference ključnih besed";
$langNonCourseKwds = "Ključne besede, ki niso del tečaja";
$langKwdsUse = "Ključne besede tečaja (mastno=ni v uporabi)";
$langTotalMDEs = "Skupno število MD vnosov:";
?>