<?php
/*
for more information: see languages.txt in the lang folder.
*/
$MessageEmptyMessageOrSubject = "Prosim, podajte temo ali besedilo sporočila";
$Inbox = "Prispela sporočila";
$Messages = "Sporočila";
$SendMessage = "Pošlji sporočilo";
$NewMessage = "Novo sporočilo";
$ComposeMessage = "Sestavi sporočilo";
$DeleteSelectedMessages = "Odstrani izbrana sporočila";
$SelectAll = "Izberi vse";
$DeselectAll = "Izberi nobenega";
$ReplyToMessage = "Odgovori";
$BackToInbox = "Nazaj v Prispela sporočila";
$MessageSentTo = "Sporočilo je bilo poslano k";
$SendMessageTo = "Pošlji";
$Myself = "meni";
$From = "Od";
$To = "Za";
$Date = "Datum";
$InvalidMessageId = "Identiteta sporočila, na katerega želite odgovoriti, ni veljavna.";
$ErrorSendingMessage = "Napaka pri poskusu pošiljanja sporočila.";
$SureYouWantToDeleteSelectedMessages = "Ste prepričani, da želite odstranite izbrana sporočila ?";
$SelectedMessagesDeleted = "Izbrana sporočila so bila odstranjena";
$EnterTitle = "Vstavite naslov sporočila";
$TypeYourMessage = "Vnesite besedilo sporočila";
$MessageDeleted = "Sporočilo je bilo odstranjeno";
$ConfirmDeleteMessage = "Ste prepričani, da želite odstraniti izbrana sporočila?";
$DeleteMessage = "Odstrani sporočilo";
$ReadMessage = "Preberi sporočilo";
$SendInviteMessage = "Pošlji sporočilo z vabilom";
$SendMessageInvitation = "Ste prepričani, da želite odposlati ta vabila ?";
$MessageTool = "Sporočila";
$WriteAMessage = "Sestavi sporočilo";
$AlreadyReadMessage = "Sporočilo je že bilo prebrano";
$UnReadMessage = "Neprebrana sporočila";
$MessageSent = "Sporočilo je bilo poslano";
$YouShouldWriteAMessage = "Napisati morate sporočilo ...";
?>