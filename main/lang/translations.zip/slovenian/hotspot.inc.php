<?php
/*
for more information: see languages.txt in the lang folder.
*/
$select = "Izberi";
$square = "Pravokotnik";
$circle = "Elipsa";
$poly = "Poligon";
$status1 = "Nariši vročo točko";
$status2_poly = "Uporabi desni klik za zapiranje poligona";
$status2_other = "Sprostite miškin gumb za shranitev vroče točke.";
$status3 = "Vroča točka je bila shranjena";
$exercise_status_1 = "Status : Vprašanje še ni zaključeno";
$exercise_status_2 = "Kliknite za zapis odgovorov";
$exercise_status_3 = "Status : Vprašanje dokončano";
$showUserPoints = "Prikaži / Skrij uporabnikove izbire";
$showHotspots = "Prikaži / Skrij vroče točke";
$labelPolyMenu = "Zapri poligon";
$triesleft = "Preostalih poskusov";
$exeFinished = "Vsi odgovori so definirani. Sedaj lahko preuredite vroče točke ali kliknite Shrani.";
$nextAnswer = "Sedaj kliknite na: &done=done";
$delineation = "Orisovanje";
$labelDelineationMenu = "Zapri orisovanje";
$oar = "Ogroženo področje";
?>