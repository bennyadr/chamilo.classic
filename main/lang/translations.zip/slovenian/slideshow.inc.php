<?php
/*
for more information: see languages.txt in the lang folder.
*/
$lang_height = "Višina";
$lang_resizing_comment = "nastavi velikost slike na naslednje dimenzije (in pikslih)";
$lang_width = "Širina";
$lang_resizing = "NASTAVI VELIKOST";
$lang_no_resizing_comment = "Prikaži vse slike v njihovi originalni velikosti. Ni prilagoditve velikosti. Drsniki se bodo pojavili avtomatično, če bo slika večja od dimenzij zaslonskega okna.";
$lang_show_thumbnails = "Prikaži ikone diapozitivov";
$lang_click_thumbnails = "Klikni na eno izmed ikon diapozitivov";
$lang_set_slideshow_options = "Prilagodi diaprojekcijo";
$lang_slideshow_options = "Možnosti diaprojekcije";
$lang_no_resizing = "BREZ prilagoditve velikosti (prednastavljeno)";
$lang_exit_slideshow = "Izhod iz diaprojekcije";
$SlideShow = "Diaprojekcija";
$lang_previous_slide = "Prejšnji diapozitiv";
$lang_next_slide = "Naslednji diapozitiv";
$lang_image = "Slika";
$lang_of = "od";
$lang_view_slideshow = "Poglej diaprojekcijo";
$FirstSlide = "Prvi diapozitiv";
$LastSlide = "Zadnj diapozitiv";
?>