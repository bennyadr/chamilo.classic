<?php
/*
for more information: see languages.txt in the lang folder.
*/
$nameTools = "nerabljena jez. variabla";
$langMdCallingTool = "Učna pot - Scorm";
$langTool = "Scorm MD operacije";
$langNotInDB = "ni vnosa v Chamilo podatkovno bazo";
$langManifestSyntax = "(sintaktična napaka v manifest datoteki)";
$langEmptyManifest = "(prazna manifest datoteka...)";
$langNoManifest = "(ni manifest datoteke...)";
$langNotFolder = "ni možno, ni mapa ...";
$langUploadHtt = "Prenesi (upload) HTT datoteko";
$langHttFileNotFound = "Nove HTT datoteke ni mogoče odpreti (prazna, prevelika)";
$langHttOk = "Nova HTT datoteka je bila prenešena";
$langHttNotOk = "prenos HTT datoteke ni bil uspešen";
$langRemoveHtt = "Odstrani HTT datoteko";
$langHttRmvOk = "HTT datoteka je bila odstranjena";
$langHttRmvNotOk = "Odstranitev HTT datoteke ni bila uspešna";
$langImport = "Uvozi imsmanifest.xml";
$langRemove = "Odstrani MDE-je";
$langAllRemovedFor = "Vsi vnosi odstranjeni za";
$langIndex = "Indeksiraj besede z PhpDig";
$langTotalMDEs = "Skupno število Scorm MDD vnosov:";
$langMainMD = "Odpri glavni MDE";
$langLines = "vrstic";
$langPlay = "Zaženi index.php";
$langNonePossible = "Nobena MD operacija ni možna";
$langOrElse = "Izberi Scorm mapo ali ID Scorm mape";
$langWorkWith = "Operacije s Scorm mapo";
$langSDI = "... Scorm mapa z SD-ID (in deljen manifest - ali pusti prazno)";
$langRoot = "koren";
$langSplitData = "Deljen manifest, in #MDe, če obstaja:";
$langMffNotOk = "Zamenjava manifest datoteke ni uspela";
$langMffOk = "Manifest datoteka je bila zamenjana";
$langMffFileNotFound = "Novo manifest datoteko ni mogoče odpreti (lahko je prazna, prevelika)";
$langUploadMff = "Nadomesti manifest datoteko";
?>