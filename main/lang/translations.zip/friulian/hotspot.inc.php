<?php
/*
for more information: see languages.txt in the lang folder.
*/
$select = "";
$square = "";
$circle = "";
$poly = "";
$status1 = "";
$status2_poly = "";
$status2_other = "";
$status3 = "";
$exercise_status_1 = "";
$exercise_status_2 = "";
$exercise_status_3 = "";
$showUserPoints = "";
$showHotspots = "";
$labelPolyMenu = "";
$triesleft = "";
$exeFinished = "";
$nextAnswer = "";
$delineation = "";
$labelDelineationMenu = "";
$oar = "";
?>