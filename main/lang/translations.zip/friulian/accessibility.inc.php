<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langClarContent = "";
$test = "";
$WCAGImage = "";
$WCAGLabel = "";
$WCAGLink = "";
$WCAGLinkLabel = "";
$errorNoLabel = "";
$AllLanguages = "";
$WCAGEditor = "";
$WCAGGoMenu = "";
$WCAGGoContent = "";
?>