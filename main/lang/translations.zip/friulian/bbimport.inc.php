<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langViewCourseMaterialImport = "";
$langViewExternalLinksImport = "";
$langViewForumImport = "";
$langImportCourseMaterial = "";
$langImportExternalLinks = "";
$langImportForum = "";
$langToolInfo = "";
$langToolName = "";
$langSelectCoursePackage = "";
$langPackageAlreadySelected = "";
$langFirstSelectPackage = "";
$langCourseToMigrate = "";
$langSelectPackage = "";
$langOpenPackageForImporting = "";
$langInformation = "";
$langChooseImportOptions = "";
$langCheckWhatIsImported = "";
$langStartImporting = "";
$langImport = "";
?>