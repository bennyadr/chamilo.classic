<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langLinkSite = "";
$langSubTitle = "";
$langAddPage = "";
$langSendPage = "";
$langCouldNot = "";
$langOkSentLink = "";
$langTooBig = "";
$langExplanation = "";
$langPgTitle = "";
$langNoLinkURL = "";
$langLinkTarget = "";
$langSameWindow = "";
$langNewWindow = "";
$langAdded = "";
$langAddLink = "";
$langNoLinkName = "";
$langEditLink = "";
$langChangePress = "";
$langLinkChanged = "";
$NoLinkName = "";
$NoLinkURL = "";
$LinkChanged = "";
$OkSentLink = "";
?>