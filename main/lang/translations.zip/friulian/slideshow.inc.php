<?php
/*
for more information: see languages.txt in the lang folder.
*/
$lang_height = "";
$lang_resizing_comment = "";
$lang_width = "";
$lang_resizing = "";
$lang_no_resizing_comment = "";
$lang_show_thumbnails = "";
$lang_click_thumbnails = "";
$lang_set_slideshow_options = "";
$lang_slideshow_options = "";
$lang_no_resizing = "";
$lang_exit_slideshow = "";
$SlideShow = "";
$lang_previous_slide = "";
$lang_next_slide = "";
$lang_image = "";
$lang_of = "";
$lang_view_slideshow = "";
$FirstSlide = "";
$LastSlide = "";
?>