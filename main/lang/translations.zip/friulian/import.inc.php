<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langPgTitle = "";
$langExplanation = "";
$langTooBig = "";
$langCouldNot = "";
$langNotAllowed = "";
$langAddPageToSite = "";
$langCouldNotSendPage = "";
$langSendPage = "";
$langPageTitleModified = "";
$langPageAdded = "";
$langAddPage = "";
$Choose = "";
?>