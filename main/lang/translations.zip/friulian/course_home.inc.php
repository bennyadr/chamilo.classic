<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langActivate = "";
$langDeactivate = "";
$langInLnk = "";
$langDelLk = "";
$langCourseCreate = "";
$langNameOfTheLink = "";
$lang_main_categories_list = "";
$langCourseAdminOnly = "";
$PlatformAdminOnly = "";
$langCombinedCourse = "";
$ToolIsNowVisible = "";
$ToolIsNowHidden = "";
$EditLink = "";
$Blog_management = "";
$Forum = "";
$Course_maintenance = "";
$TOOL_SURVEY = "";
$GreyIcons = "";
$Interaction = "";
$Authoring = "";
$Administration = "";
$IntroductionTextUpdated = "";
$IntroductionTextDeleted = "";
$SessionIdentifier = "";
$SessionName = "";
$SessionCategory = "";
$SessionData = "";
?>