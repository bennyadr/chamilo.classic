<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langHFor = "";
$langForContent = "";
$langHDropbox = "";
$langDropboxContent = "";
$langHHome = "";
$langHomeContent = "";
$langHOnline = "";
$langOnlineContent = "";
$langHClar = "";
$langHDoc = "";
$langDocContent = "";
$langHUser = "";
$langHExercise = "";
$langHPath = "";
$langHDescription = "";
$langHLinks = "";
$langHMycourses = "";
$langHAgenda = "";
$langHAnnouncements = "";
$langHChat = "";
$langHWork = "";
$langHTracking = "";
$langUserContent = "";
$langGroupContent = "";
$langExerciseContent = "";
$langPathContent = "";
$langDescriptionContent = "";
$langLinksContent = "";
$langMycoursesContent = "";
$langAgendaContent = "";
$langAnnouncementsContent = "";
$langChatContent = "";
$langWorkContent = "";
$langTrackingContent = "";
$langHSettings = "";
$langSettingsContent = "";
$langHExternal = "";
$langExternalContent = "";
$langClarContent3 = "";
$langClarContent4 = "";
$langClarContent1 = "";
$langClarContent2 = "";
$langHGroups = "";
$langGroupsContent = "";
$langGuide = "";
$HSurvey = "";
$SurveyContent = "";
$HBlogs = "";
$BlogsContent = "";
?>