<?php
/*
for more information: see languages.txt in the lang folder.
*/
$lang_new_item = "";
$lang_title_notification = "";
$lang_update_agenda = "";
$lang_new_agenda = "";
$lang_update_announcements = "";
$lang_new_announcements = "";
$lang_new_document = "";
$lang_new_exercise = "";
$lang_update_link = "";
$lang_new_link = "";
$lang_new_forum_topic = "";
$lang_new_groupforum_topic = "";
$lang_new_dropbox_file = "";
$lang_update_dropbox_file = "";
$ForumCategoryAdded = "";
$LearnpathAdded = "";
$GlossaryAdded = "";
$QuizQuestionAdded = "";
$QuizQuestionUpdated = "";
$QuizQuestionDeleted = "";
$QuizUpdated = "";
$QuizAdded = "";
$QuizDeleted = "";
$DocumentInvisible = "";
$DocumentVisible = "";
$CourseDescriptionAdded = "";
$WikiAdded = "";
$SurveyAdded = "";
$NotebookAdded = "";
$NotebookUpdated = "";
$NotebookDeleted = "";
?>