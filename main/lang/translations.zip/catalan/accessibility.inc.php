<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langClarContent = "Chamilo es un Sistema de Gestió de l'Aprenentatge i del Coneixement. Permet als professors organitzar materials d'aprenentatge, lliçons i administrar la interacció amb els seus estudiants. Tot això mitjançant un simple navegador web.";
$test = "Exercici";
$WCAGImage = "Imatge";
$WCAGLabel = "Etiqueta de la imatge";
$WCAGLink = "Enllaç";
$WCAGLinkLabel = "Etiqueta de l\'enllaç";
$errorNoLabel = "No hi ha cap etiqueta sobre la imatge";
$AllLanguages = "tots els idiomes";
$WCAGEditor = "Editor WCAG";
$WCAGGoMenu = "Vés al menú";
$WCAGGoContent = "Vés al contingut";
?>