<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langCourseProgram = "Descripció del curs";
$langThisCourseDescriptionIsEmpty = "Aquest curs actualment no es troba descrit";
$langEditCourseProgram = "Crear i editar una descripció del curs";
$QuestionPlan = "Pregunta al professor";
$langInfo2Say = "Informació a donar als estudiants";
$langOuAutreTitre = "Títol";
$langNewBloc = "Altre";
$langAddCat = "afegeix categoria";
$langAdd = "Afegeix";
$langValid = "Valida";
$langBackAndForget = "Retrocededix i oblida";
$CourseDescriptionUpdated = "La descripció dels curs ha estat actualitzada";
$CourseDescriptionDeleted = "La descripció del curs ha estat esborrada";
$CourseDescriptionIntro = "Per crear una descripció del curs, cliqueu sobre un apartat i ompliu els camps del formulari associat. <br> <br> Cliqueu desprès a Validar i ompliu un altre apartat.";
$langSaveDescription = "Guardar descripció";
?>