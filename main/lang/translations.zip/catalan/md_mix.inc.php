<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langTool = "Metadades";
$langClickKw = "Faci clic sobre la paraula clau en l\'arbre per a seleccionar-la o deseleccionar-la.";
$langKwHelp = "<br/> Clic en el botó \'+\' per a obrir, en el botó \'-\' tancar, en el botó \'++\' per a obrir tot, en el botó \'--\' per a tancar tot.<br/> <br/> Rebutjar totes les paraules clau seleccionades tancant l\'arbre i obrint-lo de nou amb el botó \'+\'.<br/>";
$langAdvanced = "Avançada";
$langSearch = "Cercar";
$langSearchCrit = "Usi l\'àrea inferior per als descriptors, una paraula per línia !";
$langNoKeywords = "Aquest curs no té paraules clau";
$langKwCacheProblem = "La paraula clau no pot ser oberta";
$langCourseKwds = "paraules clau del curs";
$langKwdsInMD = "paraules clau usades en les metadades (MD)";
$langKwdRefs = "referències de paraules clau";
$langNonCourseKwds = "paraules clau no pertanyents al curs";
$langKwdsUse = "Paraules clau del curs (negreta = sense usar)";
$langTotalMDEs = "Total d\'entrades de metadades (MD)";
?>