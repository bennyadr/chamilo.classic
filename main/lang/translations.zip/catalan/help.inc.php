<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langHFor = "Ajuda: Fòrums";
$langForContent = " Un fòrum és una eina de debat asíncrona. Mentre que un correu electrònic permet un diàleg privat entre dues persones, en els fòrums aquest diàleg serà públic o semipúblic i podran intervenir més persones.Des del punt de vista tècnic, els usuaris només ne";
$langHDropbox = "Ajuda: Compartició de fitxers";
$langDropboxContent = "Compartir documents és una eina de gestió de continguts dirigida a l\'intercanvi de dades entre iguals (p2p). Qualsevol tipus de fitxer és acceptat: Word, Excel, PDF, etc. Generarà diferents versions en els enviaments, amb el que evitarà la destrucció d\'";
$langHHome = "Ajuda: Pàgina inicial";
$langHomeContent = "<p>La pàgina inicial del vostre curs presenta una sèrie d\'eines: un text d\'introducció, una descripció del curs, una eina de publicació de Documents, etc. Aquesta pàgina és modular. Podeu visualitzar o ocultar cadascún dels elements clicant + o - (a veg";
$langHOnline = "Ajuda: Sistema de conferència en directe";
$langOnlineContent = "<b>Dokeos Live Conferencing</b> <p>Dokeos Live Conferencing (DLC) és una eina de videoconferència basada sobre el web i que utilitza la tecnologia Flash. Us permet organitzar facilament reunions virtuals entre 2, 3 o 4 llocs distants així com classes virt";
$langHClar = "Ajuda: Chamilo";
$langHDoc = "Ajuda: Documents";
$langDocContent = "Els professors poden crear pàgines web simples (\'Crear un document HTML\') o transferir a aquesta secció, arxius de qualsevol tipus (HTML, *Word, *PowerPoint, *Excel, PDF, *Flash, *QuickTime, etc.). Tingui en compte que no tots els arxius que enviï podra";
$langHUser = "Ajuda: Usuaris";
$langHExercise = "Ajuda: Exercicis";
$langHPath = "Ajuda: Itineraris formatius";
$langHDescription = "Ajuda: Descripció del curs";
$langHLinks = "Ajuda: Enllaços";
$langHMycourses = "Ajuda: Àrea d\'usuari";
$langHAgenda = "Ajuda: Agenda";
$langHAnnouncements = "Ajuda: Tauler d\'anuncis";
$langHChat = "Ajuda: Xat";
$langHWork = "Ajuda: Treballs dels estudiants";
$langHTracking = "Ajuda: Estadístiques";
$langUserContent = "";
$langGroupContent = "";
$langExerciseContent = "";
$langPathContent = "";
$langDescriptionContent = "";
$langLinksContent = "";
$langMycoursesContent = "";
$langAgendaContent = "";
$langAnnouncementsContent = "";
$langChatContent = "";
$langWorkContent = "";
$langTrackingContent = "";
$langHSettings = "";
$langSettingsContent = "";
$langHExternal = "";
$langExternalContent = "";
$langClarContent3 = "";
$langClarContent4 = "";
$langClarContent1 = "";
$langClarContent2 = "";
$langHGroups = "";
$langGroupsContent = "";
$langGuide = "";
$HSurvey = "";
$SurveyContent = "";
$HBlogs = "";
$BlogsContent = "";
?>