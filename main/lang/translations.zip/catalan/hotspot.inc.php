<?php
/*
for more information: see languages.txt in the lang folder.
*/
$select = "Seleccionar";
$square = "Quadrat";
$circle = "El·lipse";
$poly = "Polígon";
$status1 = "Dibuixar una zona interactiva";
$status2_poly = "Utilitzeu el botó dret del ratolí per tancar el polígon";
$status2_other = "Deixeu anar el botó del ratolí per guardar la zona interactiva";
$status3 = "Zona interactiva guardada";
$exercise_status_1 = "Estatus: Pregunta sense contestar";
$exercise_status_2 = "Validar les respostes";
$exercise_status_3 = "Estatus: Pregunta contestada";
$showUserPoints = "Mostrar/Ocultar clics";
$showHotspots = "Mostrar/Ocultar zones interactives";
$labelPolyMenu = "Tancar polígon";
$triesleft = "Intents restants";
$exeFinished = "Totes les zones han estat seleccionades. Ara podeu modificar les vostres respostes o clicar per validar.";
$nextAnswer = "Ara cliqueu a: &done=done";
$delineation = "Delimitació";
$labelDelineationMenu = "Tancar delimitació";
$oar = "àrea de risc";
?>