<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langScormBuilder = "Constructor de camí - constructor de curs de format Scorm";
?>