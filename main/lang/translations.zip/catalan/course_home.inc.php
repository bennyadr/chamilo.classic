<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langActivate = "Activa";
$langDeactivate = "Desactiva";
$langInLnk = "Enllaços desactivats";
$langDelLk = "Voleu realment esborrar aquest enllaç?";
$langCourseCreate = "Crear un curs web";
$langNameOfTheLink = "Nom de l\'enllaç";
$lang_main_categories_list = "Llista de categories principal";
$langCourseAdminOnly = "Només professors";
$PlatformAdminOnly = "Només administradors";
$langCombinedCourse = "Curs combinat";
$ToolIsNowVisible = "L\'eina és actualment visible";
$ToolIsNowHidden = "L\'eina és actualment no visible";
$EditLink = "Editar enllaç";
$Blog_management = "Gestió de blocs";
$Forum = "Fòrums";
$Course_maintenance = "Manteniment del curs";
$TOOL_SURVEY = "Enquestes";
$GreyIcons = "Caixa d\'eines";
$Interaction = "Interacció";
$Authoring = "Creació de continguts";
$Administration = "Administració";
$IntroductionTextUpdated = "El text d\'introducció ha estat actualitzat";
$IntroductionTextDeleted = "El text d\'introducció ha estat eliminat";
$SessionIdentifier = "Identificador de la sesión";
$SessionName = "Nom de la sessió";
$SessionCategory = "Categoria de la sessió";
$SessionData = "";
?>