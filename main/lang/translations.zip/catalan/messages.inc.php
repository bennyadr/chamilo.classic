<?php
/*
for more information: see languages.txt in the lang folder.
*/
$MessageEmptyMessageOrSubject = "Per favor, escrigui el títol i el text del seu missatge";
$Inbox = "Safata d\'entrada";
$Messages = "Missatges instantanis";
$SendMessage = "Enviar missatge";
$NewMessage = "Nou missatge";
$ComposeMessage = "Redactar";
$DeleteSelectedMessages = "Esborrar els missatges seleccionats";
$SelectAll = "Seleccionar tot";
$DeselectAll = "Anul·lar selecció";
$ReplyToMessage = "Respondre";
$BackToInbox = "Tornar a la safata d\'entrada";
$MessageSentTo = "El missatge ha estat enviat a";
$SendMessageTo = "Enviar a";
$Myself = "Jo mateix";
$From = "De";
$To = "Per a";
$Date = "Data";
$InvalidMessageId = "L\'id del missatge a contestar no és vàlid.";
$ErrorSendingMessage = "\'ha produït un error mentre s\'intentava enviar el missatge.";
$SureYouWantToDeleteSelectedMessages = "Està segur de voler esborrar els missatges seleccionats ?";
$SelectedMessagesDeleted = "Els missatges seleccionats han estat suprimits";
$EnterTitle = "Ingressi un títol";
$TypeYourMessage = "Escriba el seu missatge";
$MessageDeleted = "El missatge ha estat eliminat";
$ConfirmDeleteMessage = "Està segur que desitja esborrar aquest missatge?";
$DeleteMessage = "Esborrar missatge";
$ReadMessage = "Leer";
$SendInviteMessage = "Enviar missatge d\'invitació";
$SendMessageInvitation = "Està segur que desitja enviar les invitacions als usuaris seleccionats ?";
$MessageTool = "Eina missatges";
$WriteAMessage = "Escriure un missatge";
$AlreadyReadMessage = "Missatge llegit";
$UnReadMessage = "Missatge sense llegir";
$MessageSent = "Missatge enviat";
$YouShouldWriteAMessage = "";
?>