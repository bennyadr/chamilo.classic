<?php
/*
for more information: see languages.txt in the lang folder.
*/
$lang_height = "Altura";
$lang_resizing_comment = "redimensionar la imatge amb el següent tamany (en pixels)";
$lang_width = "Amplaria";
$lang_resizing = "Redimensionar";
$lang_no_resizing_comment = "Mostrar totes les imatges al tamany original. No redimensionar s\'ha activat. Les barres de desplaçament apareixeran automáticament si la imatge és més gran que el tamany de la seva pantalla.";
$lang_show_thumbnails = "Mostrar miniatures";
$lang_click_thumbnails = "Clic a una de les miniatures";
$lang_set_slideshow_options = "Modificar les opcions de la presentació";
$lang_slideshow_options = "Opcions de la presentació";
$lang_no_resizing = "No redimensionar (per defecte)";
$lang_exit_slideshow = "Sortir de la presentació";
$SlideShow = "Presentació";
$lang_previous_slide = "Diapositiva anterior";
$lang_next_slide = "Diapositiva següent";
$lang_image = "Imatge";
$lang_of = "de";
$lang_view_slideshow = "Veure presentació";
$FirstSlide = "";
$LastSlide = "";
?>