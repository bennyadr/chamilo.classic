<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langPgTitle = "Títol de la pàgina";
$langExplanation = "La pàgina ha d\'estar en format HTML (ex: \\"my_page.htm\\"). Serà enllaçada des de la Pàgina d\'Inici. Si vols enviar documents no-HTML (PDF, Word, Power Point, Video, etc.) utilitza <a href=../document/document.php>l\'eina de Documents</a>";
$langTooBig = "No has escollit cap fitxer a enviar, o és massa gran";
$langCouldNot = "No s\'ha pogut enviar el fitxer";
$langNotAllowed = "No perm&ecute;s";
$langAddPageToSite = "Afegeix plana al lloc";
$langCouldNotSendPage = "Aquest fitxer no està en format HMTL i no ha pogut ser enviat. Si vols enviar documents no-HTML (PDF, Word, Power Point, Video, etc.) utilitza <a href=../document/document.php>l\'eina de Documents</a>";
$langSendPage = "Pàgina a enviar";
$langPageTitleModified = "El títol de la pàgina ha estat modificat";
$langPageAdded = "Pàgina afegida";
$langAddPage = "Afegeix una pàgina";
$Choose = "Examinar";
?>