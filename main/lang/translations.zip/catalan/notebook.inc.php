<?php
/*
for more information: see languages.txt in the lang folder.
*/
$NewNote = "Nova nota";
$Note = "Nota";
$NoteDeleted = "Nota eliminada";
$NoteUpdated = "Nota actualitzada";
$NoteCreated = "Nota creada";
$YouMustWriteANote = "Per favor, escrigui una nota";
$SaveNote = "Guardar nota";
$WriteYourNoteHere = "Escrigui la seua nota ací";
$SearchByTitle = "Buscar per títol";
$WriteTheTitleHere = "Escrigui el seu títol ací";
$UpdateDate = "Data d\'actualització";
$NoteAddNew = "Afegir una nota";
$OrderByCreationDate = "Ordenar per data de creació";
$OrderByModificationDate = "Ordenar per data de modificació";
$OrderByTitle = "Ordenar per títol";
$NoteTitle = "Títol de la nota";
$NoteComment = "Contingut de la nota";
$NoteAdded = "Nota afegida";
$NoteConfirmDelete = "Desitja realment esborrar la nota?";
$AddNote = "Afegir nota";
$ModifyNote = "Modificar nota";
$BackToNoteList = "Tornar a la llista d\'anotacions";
$NotebookManagement = "Administració de nota personal";
$BackToNotesList = "Tornar al llistat de notes";
$NotesSortedByTitleAsc = "Notes en ordre ascendent per títol";
$NotesSortedByTitleDESC = "Notes en ordre descendent per títol";
$NotesSortedByUpdateDateAsc = "Notes en ordre ascendent per data d\'actualització";
$NotesSortedByUpdateDateDESC = "Notes en ordre descendent per data d\'actualització";
$NotesSortedByCreationDateAsc = "Notes en ordre ascendent per data de creació";
$NotesSortedByCreationDateDESC = "Notes en ordre descendent per data de creació";
?>