<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langViewCourseMaterialImport = "Visualitzar el material del curs que serà importat";
$langViewExternalLinksImport = "Viasulaitzar els enllaços externs que seran importats";
$langViewForumImport = "Visualitzar el forum que serà importat";
$langImportCourseMaterial = "Importar material del curs (Blackboard modul \\"Material del curs)";
$langImportExternalLinks = "Importar enllaços (Blackboard mòdul \\"Enllaços externs)";
$langImportForum = "Importar fòrums (Blackboard mòdul \\"Fòrum de discussió\\")";
$langToolInfo = "Aquesta eina importa cursos del Balckboard 5.5 (Material de cursos, foro de discussió, i enllaços externs)";
$langToolName = "Importar cursos de la pissarra";
$langSelectCoursePackage = "Seleccionat un curs empaquetat";
$langPackageAlreadySelected = "Ja heu seleccionat el curs en un paquet";
$langFirstSelectPackage = "Heu de seleccionar un paquet i obrir-lo abans de continuar amb la importació";
$langCourseToMigrate = "Curs a transferir";
$langSelectPackage = "Seleccionar un paquet";
$langOpenPackageForImporting = "Obrir aquest paquet per a importar";
$langInformation = "Informació sobre el pocès d\'importació";
$langChooseImportOptions = "Escolliu les vostres opcions d\'importació";
$langCheckWhatIsImported = "Podeu verificar per a veure que serà importat abans de començar el procés d\'importació";
$langStartImporting = "Començar la importació";
$langImport = "Importar";
?>