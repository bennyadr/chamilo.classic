<?php
/*
for more information: see languages.txt in the lang folder.
*/
$nameTools = "variable d\'idioma obsoleta";
$langMdCallingTool = "CURSOS - SCORM";
$langTool = "Operacions sobre metadades (MD) SCORM";
$langNotInDB = "no hi ha cap entrada en la base de dades (BD) de Chamilo";
$langManifestSyntax = "(error sintàctic en l\'arxiu manifest...)";
$langEmptyManifest = "(l\'arxiu manifest està buit...)";
$langNoManifest = "(no existeix l\'arxiu manifest...)";
$langNotFolder = "no és possible, això no és una carpeta...";
$langUploadHtt = "Enviar un arxiu HTT";
$langHttFileNotFound = "El nou arxiu no pot ser obert (ej., vacío, demasiado grande)";
$langHttOk = "El nou fitxer HTT ha estat enviat";
$langHttNotOk = "L\'enviament del fitxer HTT no ha estat possible";
$langRemoveHtt = "Esborrar el fitxer HTT";
$langHttRmvOk = "El fitxer HTT ha estat esborrat";
$langHttRmvNotOk = "No ha estat possible esborrar el fitxer HTT";
$langImport = "Crear les entrades de metadatos (MDE) des del fitxer manifest";
$langRemove = "Esborrar les entrades de metadatos (MDE)";
$langAllRemovedFor = "Totes les entrades han estat suprimides per a";
$langIndex = "Indexar paraules amb PhpDig";
$langTotalMDEs = "Nombre total d\'entrades de metadatos (MD) SCORM:";
$langMainMD = "Obrir la pàgina principal d\'entrades de metadatos (MDE)";
$langLines = "línies";
$langPlay = "Executar index.php";
$langNonePossible = "No és possible realitzar operacions sobre els metadatos (MD)";
$langOrElse = "Seleccioni un directori SCORM o el seu identificador";
$langWorkWith = "Treballi amb un directori SCORM";
$langSDI = "... Directori SCORM amb SD-aneu (dividir el manifest o deixar-lo buit)";
$langRoot = "arrel";
$langSplitData = "Dividir el manifest, i #MDe, si qualsevol:";
$langMffNotOk = "El reemplaçament de l\'arxiu manifest no ha estat possible";
$langMffOk = "El fitxer manifest ha estat reemplaçat";
$langMffFileNotFound = "El nou fitxer manifest no pot ser obert (ex., buit, massa gran)";
$langUploadMff = "Reemplaçar el fitxer manifest";
?>