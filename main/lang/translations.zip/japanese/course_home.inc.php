<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langActivate = "铜跟にする";
$langDeactivate = "痰跟步";
$langInLnk = "リンクを痰跟にする";
$langDelLk = "塑碰にリンクを猴近するのですか々々";
$langCourseCreate = "";
$langNameOfTheLink = "";
$lang_main_categories_list = "";
$langCourseAdminOnly = "";
$PlatformAdminOnly = "";
$langCombinedCourse = "";
$ToolIsNowVisible = "";
$ToolIsNowHidden = "";
$EditLink = "";
$Blog_management = "";
$Forum = "";
$Course_maintenance = "";
$TOOL_SURVEY = "";
$GreyIcons = "";
$Interaction = "";
$Authoring = "";
$Administration = "";
$IntroductionTextUpdated = "";
$IntroductionTextDeleted = "";
$SessionIdentifier = "";
$SessionName = "";
$SessionCategory = "";
$SessionData = "";
?>