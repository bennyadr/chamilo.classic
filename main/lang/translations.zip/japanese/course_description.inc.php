<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langCourseProgram = "";
$langThisCourseDescriptionIsEmpty = "";
$langEditCourseProgram = "";
$QuestionPlan = "";
$langInfo2Say = "";
$langOuAutreTitre = "";
$langNewBloc = "";
$langAddCat = "";
$langAdd = "";
$langValid = "";
$langBackAndForget = "";
$CourseDescriptionUpdated = "";
$CourseDescriptionDeleted = "";
$CourseDescriptionIntro = "";
$langSaveDescription = "";
?>