<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langMdCallingTool = "";
$langMdTitle = "";
$langMdDescription = "";
$langMdCoverage = "";
$langMdCopyright = "";
$langTool = "";
$langNoScript = "";
$langPressAgain = "";
$langLanguageTip = "";
$langIdentifier = "";
$langIdentifierTip = "";
$langTitleTip = "";
$langDescriptionTip = "";
$langKeyword = "";
$langKeywordTip = "";
$langCoverage = "";
$langCoverageTip = "";
$langKwNote = "";
$langClickKw = "";
$langKwHelp = "";
$langRights = "";
$langRightsTip = "";
$langVersion = "";
$langVersionTip = "";
$langStatusTip = "";
$langCreatedSize = "";
$langCreatedSizeTip = "";
$langAuthorTip = "";
$langFormat = "";
$langFormatTip = "";
$langLocation = "";
$langLocationTip = "";
$langStore = "";
$langDeleteAll = "";
$langConfirmDelete = "";
$langCourseKwds = "";
$langSearch = "";
$langSearchCrit = "";
$langStatuses = "";
$langCosts = "";
$langCopyrights = "";
$langFormats = "";
$langLngResTypes = "";
?>