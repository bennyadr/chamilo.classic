<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langTool = "";
$langClickKw = "";
$langKwHelp = "";
$langAdvanced = "";
$langSearch = "";
$langSearchCrit = "";
$langNoKeywords = "";
$langKwCacheProblem = "";
$langCourseKwds = "";
$langKwdsInMD = "";
$langKwdRefs = "";
$langNonCourseKwds = "";
$langKwdsUse = "";
$langTotalMDEs = "";
?>