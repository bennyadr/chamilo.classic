<?php
/*
for more information: see languages.txt in the lang folder.
*/
$GeneralDescription = "";
$GeneralDescriptionQuestions = "";
$GeneralDescriptionInformation = "";
$Objectives = "";
$ObjectivesInformation = "";
$ObjectivesQuestions = "";
$Topics = "";
$TopicsInformation = "";
$TopicsQuestions = "";
$Methodology = "";
$MethodologyQuestions = "";
$MethodologyInformation = "";
$CourseMaterial = "";
$CourseMaterialQuestions = "";
$CourseMaterialInformation = "";
$HumanAndTechnicalResources = "";
$HumanAndTechnicalResourcesQuestions = "";
$HumanAndTechnicalResourcesInformation = "";
$Assessment = "";
$AssessmentQuestions = "";
$AssessmentInformation = "";
?>