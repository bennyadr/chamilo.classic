<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langMdCallingTool = "";
$langMdTitle = "";
$langMdDescription = "";
$langMdCoverage = "";
$langMdCopyright = "";
$nameTools = "";
$langTool = "";
$langNoScript = "";
$langLanguageTip = "";
$langIdentifier = "";
$langIdentifierTip = "";
$langTitleTip = "";
$langDescriptionTip = "";
$langKeyword = "";
$langKeywordTip = "";
$langCoverage = "";
$langCoverageTip = "";
$langKwNote = "";
$langClickKw = "";
$langKwHelp = "";
$langLocation = "";
$langLocationTip = "";
$langStore = "";
$langDeleteAll = "";
$langConfirmDelete = "";
$langWorkOn = "";
$langNotInDB = "";
$langManifestSyntax = "";
$langEmptyManifest = "";
$langNoManifest = "";
$langNotFolder = "";
$langContinue = "";
$langCreate = "";
$langRemove = "";
$langAllRemovedFor = "";
$langRemainingFor = "";
$langIndex = "";
$langTotalMDEs = "";
$langMainMD = "";
$langOrElse = "";
$langWarningDups = "";
$langSLC = "";
?>