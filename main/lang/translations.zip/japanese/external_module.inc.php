<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langLinkSite = "サイトをリンク";
$langSubTitle = "コ〖スのホ〖ムペ〖ジメインメニュに、サイト、ペ〖ジ、URLののリンクを裁えます。:ヒント:もしペ〖ジにリンクを裁えたいときは、そのペ〖ジに乖って、URLをコピ〖して、\\"リンク\\" 腕に磨りつける。";
$langAddPage = "";
$langSendPage = "";
$langCouldNot = "";
$langOkSentLink = "";
$langTooBig = "";
$langExplanation = "";
$langPgTitle = "";
$langNoLinkURL = "";
$langLinkTarget = "";
$langSameWindow = "";
$langNewWindow = "";
$langAdded = "リンク纳裁";
$langAddLink = "";
$langNoLinkName = "";
$langEditLink = "";
$langChangePress = "";
$langLinkChanged = "";
$NoLinkName = "";
$NoLinkURL = "";
$LinkChanged = "";
$OkSentLink = "";
?>