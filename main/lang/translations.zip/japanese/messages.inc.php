<?php
/*
for more information: see languages.txt in the lang folder.
*/
$MessageEmptyMessageOrSubject = "";
$Inbox = "";
$Messages = "";
$SendMessage = "";
$NewMessage = "";
$ComposeMessage = "";
$DeleteSelectedMessages = "";
$SelectAll = "";
$DeselectAll = "";
$ReplyToMessage = "";
$BackToInbox = "";
$MessageSentTo = "";
$SendMessageTo = "";
$Myself = "";
$From = "";
$To = "";
$Date = "";
$InvalidMessageId = "";
$ErrorSendingMessage = "";
$SureYouWantToDeleteSelectedMessages = "";
$SelectedMessagesDeleted = "";
$EnterTitle = "";
$TypeYourMessage = "";
$MessageDeleted = "";
$ConfirmDeleteMessage = "";
$DeleteMessage = "";
$ReadMessage = "";
$SendInviteMessage = "";
$SendMessageInvitation = "";
$MessageTool = "";
$WriteAMessage = "";
$AlreadyReadMessage = "";
$UnReadMessage = "";
$MessageSent = "";
$YouShouldWriteAMessage = "";
?>