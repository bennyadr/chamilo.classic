<?php
/*
for more information: see languages.txt in the lang folder.
*/
$lang_new_item = "new item added";
$lang_title_notification = "Since your last visit";
$lang_update_agenda = "existing agenda item updated";
$lang_new_agenda = "new agenda item added";
$lang_update_announcements = "existing announcement updated";
$lang_new_announcements = "new announcement added";
$lang_new_document = "new document(s) added";
$lang_new_exercise = "new exercise enabled";
$lang_update_link = "existing link information updated";
$lang_new_link = "new link added";
$lang_new_forum_topic = "new topic added";
$lang_new_groupforum_topic = "new topic added to group forum";
$lang_new_dropbox_file = "";
$lang_update_dropbox_file = "";
$ForumCategoryAdded = "";
$LearnpathAdded = "";
$GlossaryAdded = "";
$QuizQuestionAdded = "";
$QuizQuestionUpdated = "";
$QuizQuestionDeleted = "";
$QuizUpdated = "";
$QuizAdded = "";
$QuizDeleted = "";
$DocumentInvisible = "";
$DocumentVisible = "";
$CourseDescriptionAdded = "";
$WikiAdded = "";
$SurveyAdded = "";
$NotebookAdded = "";
$NotebookUpdated = "";
$NotebookDeleted = "";
?>