<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langSelectOptionForBackup = "";
$langLetMeSelectItems = "";
$langCreateFullBackup = "";
$langCreateBackup = "";
$langBackupCreated = "";
$langSelectBackupFile = "";
$langImportBackup = "";
$langImportFullBackup = "";
$langImportFinished = "";
$langEvents = "";
$langAnnouncements = "";
$langDocuments = "";
$langTests = "";
$langLearnpaths = "";
$langCopyCourse = "";
$langSelectItemsToCopy = "";
$langCopyFinished = "";
$langFullRecycle = "";
$langRecycleCourse = "";
$langRecycleFinished = "";
$langRecycleWarning = "";
$langSameFilename = "";
$langSameFilenameSkip = "";
$langSameFilenameRename = "";
$langSameFilenameOverwrite = "";
$langSelectDestinationCourse = "";
$langFullCopy = "";
$langCourseDescription = "";
$langNoResourcesToBackup = "";
$langNoResourcesInBackupFile = "";
$langSelectResources = "";
$langNoResourcesToRecycles = "";
$langIncludeQuestionPool = "";
$langLocalFile = "";
$langServerFile = "";
$langNoBackupsAvailable = "";
$langNoDestinationCoursesAvailable = "";
$langBackup = "";
$langImportBackupInfo = "";
$langCreateBackupInfo = "";
$ToolIntro = "";
$UploadError = "";
$DocumentsWillBeAddedToo = "";
$ToExportLearnpathWithQuizYouHaveToSelectQuiz = "";
$ArchivesDirectoryNotWriteableContactAdmin = "";
$DestinationCourse = "";
?>