<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langHFor = "柴的技のへルプ";
$langForContent = "<p>この柴的技は、≈矢机∽で乖う柴的技です。お高いの箕粗のすれちがいを涟捏とした皮侠のための苹恶です。排灰メ〖ルが１滦１の滦厦を钓すとすれば、柴的技は给鼎、染给鼎の剩眶の客」の滦厦を涂えるものです。</p><p>祷窖弄には、池栏紧矾は、极尸のブラウザだけをもpてば、clarolineの柴的技をつかえます。</p><p>柴的技を寥骏するためには、≈瓷妄∽adminをクリックします。皮侠の肋年は肌のようにします。</p><p><b>カテゴリ〖 > 柴的技 > トピック > > Answers</b></p>";
$langHDropbox = "";
$langDropboxContent = "";
$langHHome = "ホ〖ムペ〖ジへルプ";
$langHomeContent = "<p>网脱荚の守倒を雇えて、clarolineのツ〖ルは、介袋觉轮でもまっさらではありません。すべてのツ〖ルには、すぐにでもなにかできるように、井さな毋が介袋觉轮でのっています。その毋を饯赖したり、猴近してたりして、おつかいください。</p><p>毋えば、このコ〖スのウエブサイトのホ〖ムペ〖ジには,つぎのようなテキストがのっています。\'これは、あなたのコ〖スの棱汤矢今です。あなたに圭うように饯赖してください。うんぬん\' すべてのツ〖ルには、票じような拎侯缄界、≈纳裁、猴近、饯赖∽があります。これは瓢弄";
$langHOnline = "";
$langOnlineContent = "";
$langHClar = "スタ〖トのへルプ";
$langHDoc = "≈矢今∽のヘルプ";
$langDocContent = "<p>この矢今ツ〖ルは、コンピュ〖タのファイルマネ〖ジャに击ています。</p><p>HTML, Word, Powerpoint, Excel, Acrobat, Flash, Quicktime, etc.などのファイルをアップロ〖ド叫丸ます。停办、簇看を失うべきは、あなたの池栏が、そのファイルを粕める茨董にあるかどうか、ということのみです。いくつかのファイルタイプには、ウイルスがつきものです。そのようなファイルに滦する奥链についてはあなたの勒扦です。アップロ〖ドの涟に、ウイルスチェックソフトで矢今をチ";
$langHUser = "≈ユ〖ザ∽のヘルプ";
$langHExercise = "";
$langHPath = "";
$langHDescription = "";
$langHLinks = "";
$langHMycourses = "";
$langHAgenda = "";
$langHAnnouncements = "";
$langHChat = "";
$langHWork = "";
$langHTracking = "";
$langUserContent = "<b>≈舔充∽roles</b><p>≈舔充∽はコンピュ〖タの怠墙ではありません。システム笨脱惧の咐驼ではないのです。≈舔充∽は、客に充り碰てられた≈この客茂?∽という罢蹋に戮喇りません。あなたは、≈舔充∽の≈饯赖∽で、それらを恃构することが叫丸ます。≈兜徽∽≈アシスタント∽≈池栏∽≈爽啼荚∽≈漓嚏踩∽。。。。</p><hr";
$langGroupContent = "";
$langExerciseContent = "";
$langPathContent = "";
$langDescriptionContent = "";
$langLinksContent = "";
$langMycoursesContent = "";
$langAgendaContent = "";
$langAnnouncementsContent = "";
$langChatContent = "";
$langWorkContent = "";
$langTrackingContent = "";
$langHSettings = "";
$langSettingsContent = "";
$langHExternal = "";
$langExternalContent = "";
$langClarContent3 = "</p><p><b>兜伴妄侠</b><p>兜徽にとってインタ〖ネットのもとでのコ〖スの洁洒は、兜伴妄侠の啼玛でもあります。";
$langClarContent4 = "<p>は、あなた极咳の鉴度纷茶をすすめるそれぞれの檬超で、あなたを缄锦けしようと雇えています。ツ〖ルのデザインからはじまり、その琵圭弄な疤弥烧け、および池栏たちの池浆に滦して涂える逼读についての删擦に魂るまで。</p>";
$langClarContent1 = "is the virtual campus of";
$langClarContent2 = "ここでは、兜徽とアシスタントが、コ〖スのウエブサイトを侯ったり瓷妄したりします。池栏は、矢今や徒年、攫鼠を粕みます。また遍浆啼玛を豺いたり、极尸の矢今を给倡したり、柴的技での皮侠に徊裁します。</p><b>判峡について</b><p>あなたが池栏なら、≈肌のコ〖スを联ぶ(池栏)∽で、コ〖スを联んでください。</p><p>兜徽、颅すてんとの眷圭は、≈コ〖スを侯喇(兜徽)∽を联んでください。 コ〖スコ〖ド、池彩やコ〖スタイトルを淡掐してください。それが赖撅に姜ったら、侯ったサイトを笨脱できます。また鉴度柒推に炳";
$langHGroups = "";
$langGroupsContent = "";
$langGuide = "";
$HSurvey = "";
$SurveyContent = "";
$HBlogs = "";
$BlogsContent = "";
?>