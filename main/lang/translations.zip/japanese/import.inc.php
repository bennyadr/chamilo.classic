<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langPgTitle = "ペ〖ジタイトル";
$langExplanation = "ペ〖ジはHTMLフォ〖マットでなければいけません。(e.g. \\"my_page.htm\\"). ペ〖ジはホ〖ムペ〖ジからリンクされます。もしHTMLではない矢今を流慨したい箕は(PDF, Word, Power Point, Video, など) 肌のツ〖ルを脱いて布さい <a href";
$langTooBig = "ファイルが络きすぎるので、联买できません。";
$langCouldNot = "ファイルが流れませんでした。";
$langNotAllowed = "このコ〖ス减怪が钓材されていません";
$langAddPageToSite = "ペ〖ジを裁える";
$langCouldNotSendPage = "このファイルは HTMLフォ〖マットではないので、觅れませんでした。PDF, Word, Power Point, Video, などの矢今を流りたいのであれば肌のリンクを网脱布さい<a href";
$langSendPage = "ペ〖ジを流る";
$langPageTitleModified = "兜徽がペ〖ジタイトルを恃构しました";
$langPageAdded = "ペ〖ジを裁えました";
$langAddPage = "ペ〖ジを裁える";
$Choose = "";
?>