<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langScormVersion = "";
$langScormRestarted = "";
$langScormNoNext = "";
$langScormNoPrev = "";
$langScormTime = "";
$langScormNoOrder = "";
$langScormScore = "";
$langScormLessonTitle = "";
$langScormStatus = "";
$langScormToEnter = "";
$langScormFirstNeedTo = "";
$langScormThisStatus = "";
$langScormClose = "";
$langScormRestart = "";
$langScormCompstatus = "";
$langScormIncomplete = "";
$langScormPassed = "";
$langScormFailed = "";
$langScormPrevious = "";
$langScormNext = "";
$langScormTitle = "";
$langScormMystatus = "";
$langScormNoItems = "";
$langScormNoStatus = "";
$langScormLoggedout = "";
$langScormCloseWindow = "";
$ScormBrowsed = "";
$langScormExitFullScreen = "";
$langScormFullScreen = "";
$langScormNotAttempted = "";
$langCharset = "";
$langLocal = "";
$langRemote = "";
$langAutodetect = "";
$langAccomplishedStepsTotal = "";
$langUnknown = "";
$AreYouSureToDeleteSteps = "";
$Origin = "";
$Local = "";
$Remote = "";
$FileToUpload = "";
$ContentMaker = "";
$ContentProximity = "";
$UploadLocalFileFromGarbageDir = "";
$ThisItemIsNotExportable = "";
$MoveCurrentChapter = "";
$GenericScorm = "";
$UnknownPackageFormat = "";
$Attempt = "";
$MoveTheCurrentForum = "";
$WarningWhenEditingScorm = "";
$AdditionalProfileField = "";
?>