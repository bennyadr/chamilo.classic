<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langClarContent = "";
$test = "テスト";
$WCAGImage = "画像";
$WCAGLabel = "画像ラベル";
$WCAGLink = "リンク";
$WCAGLinkLabel = "リンクラベル";
$errorNoLabel = "画像にラベルがありません";
$AllLanguages = "全ての言語";
$WCAGEditor = "";
$WCAGGoMenu = "メニューへ";
$WCAGGoContent = "コンテンツへ";
?>