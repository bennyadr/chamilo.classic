<?php
/*
for more information: see languages.txt in the lang folder.
*/
$NewNote = "";
$Note = "";
$NoteDeleted = "";
$NoteUpdated = "";
$NoteCreated = "";
$YouMustWriteANote = "";
$SaveNote = "";
$WriteYourNoteHere = "";
$SearchByTitle = "";
$WriteTheTitleHere = "";
$UpdateDate = "";
$NoteAddNew = "";
$OrderByCreationDate = "";
$OrderByModificationDate = "";
$OrderByTitle = "";
$NoteTitle = "";
$NoteComment = "";
$NoteAdded = "";
$NoteConfirmDelete = "";
$AddNote = "";
$ModifyNote = "";
$BackToNoteList = "";
$NotebookManagement = "";
$BackToNotesList = "";
$NotesSortedByTitleAsc = "";
$NotesSortedByTitleDESC = "";
$NotesSortedByUpdateDateAsc = "";
$NotesSortedByUpdateDateDESC = "";
$NotesSortedByCreationDateAsc = "";
$NotesSortedByCreationDateDESC = "";
?>