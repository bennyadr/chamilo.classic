<?php
/*
for more information: see languages.txt in the lang folder.
*/
$TermAddNew = "";
$TermName = "";
$TermDefinition = "";
$TermDeleted = "";
$TermUpdated = "";
$TermConfirmDelete = "";
$TermAddButton = "";
$TermUpdateButton = "";
$TermEdit = "";
$TermDeleteAction = "";
$OrderBy = "";
$CreationDate = "";
$UpdateDate = "";
$PreSelectedOrder = "";
$TermAdded = "";
$YouMustEnterATermName = "";
$YouMustEnterATermDefinition = "";
$TableView = "";
$GlossaryTermAlreadyExistsYouShouldEditIt = "";
$GlossaryManagement = "";
$TermMoved = "";
$ShowGlossaryInExtraToolsTitle = "";
$ShowGlossaryInExtraToolsComment = "";
?>