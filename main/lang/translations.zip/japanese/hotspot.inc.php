<?php
/*
for more information: see languages.txt in the lang folder.
*/
$select = "Select";
$square = "Square";
$circle = "Elipse";
$poly = "Polygon";
$status1 = "Draw a hotspot.";
$status2_poly = "Use right-click to close the polygon.";
$status2_other = "Release the mousebutton to save the hotspot.";
$status3 = "Hotspot saved";
$exercise_status_1 = "Status: Question not yet terminated";
$exercise_status_2 = "Click to submit your answers to the question";
$exercise_status_3 = "Status: Question terminated";
$showUserPoints = "Show/Hide userclicks";
$showHotspots = "Show / Hide hotspots";
$labelPolyMenu = "Close polygon";
$triesleft = "Attempts left";
$exeFinished = "All answers done. You can now rearrange the hotspots or click button below image to submit";
$nextAnswer = "Now click on: &done=done";
$delineation = "";
$labelDelineationMenu = "";
$oar = "";
?>