<?php
/*
for more information: see languages.txt in the lang folder.
*/
$LinkMoved = "";
$langLinkName = "";
$langLinkAdd = "";
$langLinkAdded = "";
$langLinkMod = "";
$langLinkModded = "";
$langLinkDel = "";
$langLinkDeleted = "";
$langLinkDelconfirm = "";
$langAllLinksDel = "";
$langCategoryName = "";
$langCategoryAdd = "";
$langCategoryAdded = "";
$langCategoryModded = "";
$langCategoryDel = "";
$langCategoryDeleted = "";
$langCategoryDelconfirm = "";
$langAllCategoryDel = "";
$langGiveURL = "";
$langGiveCategoryName = "";
$langNoCategory = "";
$showall = "";
$shownone = "";
$langListDeleted = "";
$langAddLink = "";
$langDelList = "";
$langModifyLink = "";
$langCsvImport = "";
$langCsvFileNotFound = "";
$langCsvFileNoSeps = "";
$langCsvFileNoURL = "";
$langCsvFileLine1 = "";
$langCsvLinesFailed = "";
$langCsvLinesOld = "";
$langCsvLinesNew = "";
$langCsvExplain = "";
$langLinkUpdated = "";
$langAll_Link_Deleted = "";
$langOnHomepage = "";
$langShowLinkOnHomepage = "";
$General = "";
$SearchFeatureDoIndexLink = "";
$langSaveLink = "";
$langSaveCategory = "";
$BackToLinksOverview = "";
$AddTargetOfLinkOnHomepage = "";
?>