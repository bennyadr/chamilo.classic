<?php
/*
for more information: see languages.txt in the lang folder.
*/
$nameTools = "";
$langMdCallingTool = "";
$langTool = "";
$langNotInDB = "";
$langManifestSyntax = "";
$langEmptyManifest = "";
$langNoManifest = "";
$langNotFolder = "";
$langUploadHtt = "";
$langHttFileNotFound = "";
$langHttOk = "";
$langHttNotOk = "";
$langRemoveHtt = "";
$langHttRmvOk = "";
$langHttRmvNotOk = "";
$langImport = "";
$langRemove = "";
$langAllRemovedFor = "";
$langIndex = "";
$langTotalMDEs = "";
$langMainMD = "";
$langLines = "";
$langPlay = "";
$langNonePossible = "";
$langOrElse = "";
$langWorkWith = "";
$langSDI = "";
$langRoot = "";
$langSplitData = "";
$langMffNotOk = "";
$langMffOk = "";
$langMffFileNotFound = "";
$langUploadMff = "";
?>