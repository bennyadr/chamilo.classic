<?php
/*
for more information: see languages.txt in the lang folder.
*/
$MessageEmptyMessageOrSubject = "Lütfen konu yada mesaj&#305; bo&#351; b&#305;rakmay&#305;n&#305;z";
$Inbox = "Gelen Kutusu";
$Messages = "Mesajlar";
$SendMessage = "Mesaj gönder";
$NewMessage = "Yeni mesaj";
$ComposeMessage = "Mesaj yaz";
$DeleteSelectedMessages = "Seçili mesajlar&#305; sil";
$SelectAll = "Tümünü seç";
$DeselectAll = "Seçimleri kald&#305;r";
$ReplyToMessage = "Yan&#305;tla";
$BackToInbox = "Gelen kutusuna dön";
$MessageSentTo = "Mesaj gönderilen";
$SendMessageTo = "Gönderilen";
$Myself = "Ben";
$From = "Gönderen";
$To = "Al&#305;c&#305;";
$Date = "Tarih";
$InvalidMessageId = "Mesaj&#305;n id cevap için geçerli de&#287;il.";
$ErrorSendingMessage = "Mesaj yollan&#305;rken bir hata olu&#351;tu";
$SureYouWantToDeleteSelectedMessages = "Seçilen mesajlar&#305; silmek istedi&#287;inizden emin misiniz?";
$SelectedMessagesDeleted = "Seçilen mesajlar silindi";
$EnterTitle = "Lütfen ba&#351;l&#305;k girin";
$TypeYourMessage = "Mesaj&#305;n&#305;z&#305; buraya yaz&#305;n";
$MessageDeleted = "Mesaj silindi";
$ConfirmDeleteMessage = "Seçili mesaj&#305; silmek istedi&#287;inizden emin misiniz?";
$DeleteMessage = "Mesaj&#305; sil";
$ReadMessage = "Mesaj&#305; oku";
$SendInviteMessage = "Davet mesaj&#305; gönder";
$SendMessageInvitation = "Bu davetiyeleri göndermek istedi&#287;inize emin misiniz?";
$MessageTool = "Mesaj araçlar&#305;";
$WriteAMessage = "Mesaj yaz";
$AlreadyReadMessage = "Okunmu&#351; mesaj";
$UnReadMessage = "Okunmam&#305;&#351; mesaj";
$MessageSent = "Mesaj gönderildi";
$YouShouldWriteAMessage = "";
?>