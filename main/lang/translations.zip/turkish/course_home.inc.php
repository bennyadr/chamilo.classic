<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langActivate = "Göster";
$langDeactivate = "Gizle";
$langInLnk = "Gizli araç ve ba&#287;lant&#305;lar";
$langDelLk = "Bu ba&#287;lant&#305;y&#305; silmek istiyor musunuz?";
$langCourseCreate = "Ders web sitesi olu&#351;tur";
$langNameOfTheLink = "Ba&#287;lant&#305; ad&#305;";
$lang_main_categories_list = "Ana kategori listesi";
$langCourseAdminOnly = "Sadece Ö&#287;retmenler";
$PlatformAdminOnly = "Sadece Platform Yöneticileri";
$langCombinedCourse = "Birle&#351;tirilmi&#351; dersler";
$ToolIsNowVisible = "Bu araç &#351;imdi görülebilir";
$ToolIsNowHidden = "Bu araç &#351;imdi görülmez";
$EditLink = "Ba&#287;lant&#305; ekle";
$Blog_management = "Projeler";
$Forum = "Forumlar";
$Course_maintenance = "Yedekleme";
$TOOL_SURVEY = "Anketler";
$GreyIcons = "Araçlar";
$Interaction = "Etkile&#351;im";
$Authoring = "Yazar";
$Administration = "Yönetim";
$IntroductionTextUpdated = "Giri&#351; güncellendi";
$IntroductionTextDeleted = "Giri&#351; silindi";
$SessionIdentifier = "Sömestr Tan&#305;mlay&#305;c&#305;s&#305;";
$SessionName = "Sömestr Ad&#305;";
$SessionCategory = "Sömestr Kategorisi";
$SessionData = "Sömestr Verileri";
?>