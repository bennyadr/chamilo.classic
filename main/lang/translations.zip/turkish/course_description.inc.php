<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langCourseProgram = "Ders Açýklamalarý";
$langThisCourseDescriptionIsEmpty = "Bu ders için bir açýklama yapýlmamýþtýr";
$langEditCourseProgram = "Form kullanarak hazýrla";
$QuestionPlan = "Ders yetkilisine soru";
$langInfo2Say = "Kullan&#305;c&#305;lara verilecek bilgiler";
$langOuAutreTitre = "Ba&#351;l&#305;k";
$langNewBloc = "Diðer";
$langAddCat = "kategori ekle";
$langAdd = "Ekle";
$langValid = "Geçerli";
$langBackAndForget = "Ýptal";
$CourseDescriptionUpdated = "Ders tan&#305;m&#305; güncellendi";
$CourseDescriptionDeleted = "Ders tan&#305;m&#305; silindi";
$CourseDescriptionIntro = "Bir ders tan&#305;m&#305; olu&#351;turmak için ba&#351;l&#305;&#287;a t&#305;klay&#305;p do&#287;ru form alan&#305;n&#305; doldurun.<br><br> Daha sonra Tamam\'a t&#305;klay&#305;p ba&#351;ka bir ba&#351;l&#305;&#287;&#305; doldurun.";
$langSaveDescription = "Tan&#305;m&#305; Kaydet";
?>