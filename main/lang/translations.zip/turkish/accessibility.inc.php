<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langClarContent = "<p><b>E&#287;itmen</b></p> <p>Dokeos bir Ö&#287;renme ve Bilgi Yönetim Sistemidir. E&#287;itmenlere ö&#287;renme materyallerini, ö&#287;renme yollar&#305;n&#305; organize etmeyi ve ö&#287;rencileri ile olan etkile&#351;imi yönetmesi sa&#287;lar. Bunlar&#3";
$test = "deneme";
$WCAGImage = "Resim";
$WCAGLabel = "Resim etiketi";
$WCAGLink = "Ba&#287;lant&#305;";
$WCAGLinkLabel = "Ba&#287;lant&#305; etiketi";
$errorNoLabel = "Resimde etiket yok";
$AllLanguages = "bütün diller";
$WCAGEditor = "WCAG Editörü";
$WCAGGoMenu = "Menüye git";
$WCAGGoContent = "&#304;çeri&#287;e git";
?>