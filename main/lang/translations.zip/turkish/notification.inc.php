<?php
/*
for more information: see languages.txt in the lang folder.
*/
$lang_new_item = "yeni parça eklendi";
$lang_title_notification = "Son ziyaretinizden beri";
$lang_update_agenda = "varolan etkinlik güncellendi";
$lang_new_agenda = "yeni etkinlik eklendi";
$lang_update_announcements = "varolan duyuru güncellendi";
$lang_new_announcements = "yeni duyuru eklendi";
$lang_new_document = "yeni belge(ler) eklendi";
$lang_new_exercise = "yeni al&#305;&#351;t&#305;rma aktif";
$lang_update_link = "varolan ba&#287;lant&#305; güncellendi";
$lang_new_link = "yeni ba&#287;lant&#305; eklendi";
$lang_new_forum_topic = "yeni ba&#351;l&#305;k eklendi";
$lang_new_groupforum_topic = "grup forumuna yeni ba&#351;l&#305;k eklendi";
$lang_new_dropbox_file = "yeni dosya al&#305;nd&#305;";
$lang_update_dropbox_file = "gelen kutusundaki dosyanÄ±z gÃŒncellendi";
$ForumCategoryAdded = "Forum kategorisi eklendi";
$LearnpathAdded = "Ders eklendi";
$GlossaryAdded = "Sözlü&#287;e yeni terim eklendi";
$QuizQuestionAdded = "K&#305;sa s&#305;nava yeni soru eklendi";
$QuizQuestionUpdated = "K&#305;sa s&#305;nav sorusu güncellendi";
$QuizQuestionDeleted = "K&#305;sa s&#305;nav sorusu silindi";
$QuizUpdated = "K&#305;sa s&#305;nav güncellendi";
$QuizAdded = "K&#305;sa s&#305;nav eklendi";
$QuizDeleted = "K&#305;sa s&#305;nav silindi";
$DocumentInvisible = "Belge art&#305;k görünmez";
$DocumentVisible = "Belge art&#305;k görünebilir";
$CourseDescriptionAdded = "Kurs aç&#305;klamas&#305; eklendi";
$WikiAdded = "Wiki eklendi";
$SurveyAdded = "Anket eklendi";
$NotebookAdded = "Not eklendi";
$NotebookUpdated = "Not Defteri güncellendi";
$NotebookDeleted = "Not silindi";
?>