<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langTool = "Metadata";
$langClickKw = "Seçmek veya iptal etmek için dallardaki bir kelimenin üzerine t&#305;klay&#305;n";
$langKwHelp = "<br/> Click \'+\' button to open, \'-\' button to close, \'++\' button to open all, \'--\' button to close all.<br/> <br/> Clear all selected keywords by closing the tree and opening it again with the \'+\' button.<br/> Alt-click \'+\' re-selects the prev";
$langAdvanced = "Geli&#351;mi&#351;";
$langSearch = "Ara&#351;t&#305;rma";
$langSearchCrit = "aç&#305;klay&#305;c&#305; kelimeler için a&#351;a&#287;&#305;daki alan&#305; kullan&#305;n, her sat&#305;ra bir kelime !";
$langNoKeywords = "Bu ders için anahtar kelime yok";
$langKwCacheProblem = "Anahtar kelime ön belle&#287;i aç&#305;lam&#305;yor.";
$langCourseKwds = "ders anahtar kelimeleri";
$langKwdsInMD = "MD içinde kullan&#305;lan anahtar kelimeler";
$langKwdRefs = "anahtar kelime referanslar&#305;";
$langNonCourseKwds = "Derse ait olmayan anahtar kelimeler";
$langKwdsUse = "Ders anahtar kelimeleri (koyu = kullan&#305;lm&#305;yor)";
$langTotalMDEs = "MD giri&#351;lerinin toplam say&#305;s&#305;:";
?>