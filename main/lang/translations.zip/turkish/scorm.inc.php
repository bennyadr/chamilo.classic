<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langScormVersion = "sürüm";
$langScormRestarted = "&#350;imdilik tamamlanmam&#305;&#351; dersler.";
$langScormNoNext = "Bu son ders.";
$langScormNoPrev = "Bu ilk ders.";
$langScormTime = "Zaman";
$langScormNoOrder = "Verilmi&#351; sipari&#351; yok, herhangi bir dersin üzerine t&#305;klayabilirsiniz.";
$langScormScore = "Sonuç";
$langScormLessonTitle = "Bölüm ba&#351;l&#305;&#287;&#305;";
$langScormStatus = "Durum";
$langScormToEnter = "Giri&#351;";
$langScormFirstNeedTo = "Öncelikle tamamlamal&#305;s&#305;n&#305;z";
$langScormThisStatus = "&#350;imdi bu ders";
$langScormClose = "Sonland&#305;r";
$langScormRestart = "Yeniden ba&#351;lat";
$langScormCompstatus = "tamamland&#305;";
$langScormIncomplete = "Tamamlanmad&#305;";
$langScormPassed = "Geçti";
$langScormFailed = "Ba&#351;ar&#305;s&#305;z";
$langScormPrevious = "Önceki";
$langScormNext = "Sonraki";
$langScormTitle = "Chamilo Scorm oyuncusu";
$langScormMystatus = "Durumum";
$langScormNoItems = "Bu ba&#351;l&#305;k hiç bir alt ba&#351;l&#305;k içermiyor.";
$langScormNoStatus = "Bu ba&#351;l&#305;k için durum yok";
$langScormLoggedout = "Scrom alan&#305;ndan ç&#305;k&#305;ld&#305;.";
$langScormCloseWindow = "Pencereleri kapat";
$ScormBrowsed = "";
$langScormExitFullScreen = "Normal ekrana dön";
$langScormFullScreen = "Tam Ekran";
$langScormNotAttempted = "Çal&#305;&#351;mad&#305;";
$langCharset = "Karakter Seti";
$langLocal = "Yerel";
$langRemote = "Uzak";
$langAutodetect = "Otomatik Tespit";
$langAccomplishedStepsTotal = "Tamamlanan ders toplam&#305;";
$langUnknown = "Bilinmiyor";
$AreYouSureToDeleteSteps = "Bu ad&#305;mlar&#305; silmek istedi&#287;nizden emin misiniz?";
$Origin = "Yönetim Arac&#305;";
$Local = "Yerel";
$Remote = "Uzak";
$FileToUpload = "";
$ContentMaker = "";
$ContentProximity = "";
$UploadLocalFileFromGarbageDir = "";
$ThisItemIsNotExportable = "";
$MoveCurrentChapter = "";
$GenericScorm = "";
$UnknownPackageFormat = "";
$Attempt = "";
$MoveTheCurrentForum = "";
$WarningWhenEditingScorm = "";
$AdditionalProfileField = "";
?>