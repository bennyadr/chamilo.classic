<?php
/*
for more information: see languages.txt in the lang folder.
*/
$TermAddNew = "Yeni terim ekle";
$TermName = "Terim";
$TermDefinition = "Terim tan&#305;m&#305;";
$TermDeleted = "Terim kald&#305;r&#305;ld&#305;";
$TermUpdated = "Terim güncellendi";
$TermConfirmDelete = "Bu terimi silmek istiyor musunuz?";
$TermAddButton = "Terimi kaydet";
$TermUpdateButton = "Terimi güncelle";
$TermEdit = "Terimi düzenle";
$TermDeleteAction = "Terimi sil";
$OrderBy = "S&#305;rala";
$CreationDate = "Olu&#351;turma tarihi";
$UpdateDate = "Güncellendi";
$PreSelectedOrder = "Ön tan&#305;ml&#305;";
$TermAdded = "Terim eklendi";
$YouMustEnterATermName = "Bir terim girmelisiniz";
$YouMustEnterATermDefinition = "Terime ait bir tan&#305;mlama girmelisiniz";
$TableView = "Tablo görünümü";
$GlossaryTermAlreadyExistsYouShouldEditIt = "Bu terim zaten var. Lütfen terim ad&#305;n&#305; de&#287;i&#351;tiriniz";
$GlossaryManagement = "Sözlük Yönetimi";
$TermMoved = "Terim ta&#351;&#305;nd&#305;";
$ShowGlossaryInExtraToolsTitle = "Ekstra araçlarda teknik terimleri göster";
$ShowGlossaryInExtraToolsComment = "";
?>