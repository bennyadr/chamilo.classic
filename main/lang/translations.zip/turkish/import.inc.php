<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langPgTitle = "Sayfanýn baþlýðý";
$langExplanation = "Sayfa HTML formatýnda olmalýdýr (örnek: \\"felsefe_odevi.htm\\"). Eðer HTML olmayan bir dosya göndermek istiyorsanýz (PDF, Word, Power Point, Video, etc.) use <a href=../document/document.php>Belge Araçlarýný kullanýnýz</a>";
$langTooBig = "Bir dosya seçmediniz veya çok büyük";
$langCouldNot = "Dosya gönderilemedi";
$langNotAllowed = "Ýzin verilmiyor";
$langAddPageToSite = "Siteye sayfa ekle";
$langCouldNotSendPage = "Bu sayfa HTML formatýnda deðil bu nedenle gönderilemez. Eðer HTML olmayan bir dosya göndermek istiyorsanýz (PDF, Word, Power Point, Video, etc.) <a href=../document/document.php>Belge Araçlarýný kullanýnýz</a>";
$langSendPage = "Gönderilecek sayfa";
$langPageTitleModified = "Sayfa baþlýðý deðiþtirildi";
$langPageAdded = "Sayfa eklendi";
$langAddPage = "Sayfa ekle";
$Choose = "Seç";
?>