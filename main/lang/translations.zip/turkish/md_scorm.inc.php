<?php
/*
for more information: see languages.txt in the lang folder.
*/
$nameTools = "kullan&#305;lmayan lisan de&#287;i&#351;keni";
$langMdCallingTool = "KURS - SCORM";
$langTool = "Scorm MD i&#351;lemleri";
$langNotInDB = "DB giri&#351;i yok";
$langManifestSyntax = "(aç&#305;klama dosyas&#305;nda yaz&#305;m hatas&#305;...)";
$langEmptyManifest = "(bo&#351; aç&#305;klama dosyas&#305;...)";
$langNoManifest = "(aç&#305;klama dosyas&#305; yok...)";
$langNotFolder = "mümkün de&#287;il, o bir klasör de&#287;il...";
$langUploadHtt = "HTT dosyas&#305; gönder";
$langHttFileNotFound = "Yeni HTT dosyas&#305; aç&#305;lamad&#305; (bo&#351;, çok büyük vs)";
$langHttOk = "Yeni HTT dosyas&#305; sisteme gönderildi.";
$langHttNotOk = "HTT dosya transferi ba&#351;ar&#305;s&#305;z";
$langRemoveHtt = "HTT dosyas&#305; sil";
$langHttRmvOk = "HTT dosyas&#305; silindi";
$langHttRmvNotOk = "HTT dosya silme i&#351;lemi ba&#351;ar&#305;s&#305;z oldu";
$langImport = "Listeden MDE olu&#351;tur";
$langRemove = "MDE sil";
$langAllRemovedFor = "All entries removed for";
$langIndex = "Index Words with PhpDig";
$langTotalMDEs = "Scorm MD giri&#351;leri toplam say&#305;s&#305;:";
$langMainMD = "Ana MDE aç";
$langLines = "sat&#305;r";
$langPlay = "index.php yi oynat";
$langNonePossible = "MD i&#351;lemleri mümkün de&#287;il";
$langOrElse = "Bir Scorm Direktörü veya ID si seç";
$langWorkWith = "Scorm Direktörü ile çal&#305;&#351;";
$langSDI = "... Scorm Directory with SD-id (and split manifest - or leave empty)";
$langRoot = "ana dizin";
$langSplitData = "Split manifests, and #MDe, if any:";
$langMffNotOk = "Liste dosyas&#305;n&#305; tekrar yerine koyma  i&#351;lemi ba&#351;ar&#305;s&#305;z oldu";
$langMffOk = "Liste dosyas&#305; tekrar yerine konuldu";
$langMffFileNotFound = "Yeni liste dosyas&#305; aç&#305;lam&#305;yor (bo&#351;, çok büyük vs)";
$langUploadMff = "Liste dosyas&#305;n&#305; tekrar yerine koy";
?>