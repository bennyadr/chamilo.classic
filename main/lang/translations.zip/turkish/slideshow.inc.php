<?php
/*
for more information: see languages.txt in the lang folder.
*/
$lang_height = "Yükseklik";
$lang_resizing_comment = "görüntüyü &#351;u boyutlara göre ayarla (pixel olarak)";
$lang_width = "Geni&#351;lik";
$lang_resizing = "YEN&#304;DEN BOYUTLANDIR";
$lang_no_resizing_comment = "Show all images in their original size. No resizing is done. Scrollbars will automatically appear if the image is larger than your monitor size.";
$lang_show_thumbnails = "T&#305;rnak resimleri göster";
$lang_click_thumbnails = "T&#305;rnak resimlerden birine t&#305;klay&#305;n";
$lang_set_slideshow_options = "Slayt Gösterisi seçeneklerini ayarla";
$lang_slideshow_options = "Slayt Gösterisi seçenekleri";
$lang_no_resizing = "YEN&#304;DEN BOYUTLANDIRMA YOK (Varsay&#305;lan)";
$lang_exit_slideshow = "Slayt gösterisinden ç&#305;k";
$SlideShow = "Slayt Gösterisi";
$lang_previous_slide = "Önceki Slayt";
$lang_next_slide = "Sonraki Slayt";
$lang_image = "Resim";
$lang_of = "/";
$lang_view_slideshow = "Slayt Gösterisini görüntüle";
$FirstSlide = "";
$LastSlide = "";
?>