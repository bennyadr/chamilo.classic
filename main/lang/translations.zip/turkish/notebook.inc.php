<?php
/*
for more information: see languages.txt in the lang folder.
*/
$NewNote = "Yeni not";
$Note = "Not";
$NoteDeleted = "Not silindi";
$NoteUpdated = "Not güncellendi";
$NoteCreated = "Not olu&#351;turuldu";
$YouMustWriteANote = "Lütfen bir not yaz&#305;n";
$SaveNote = "Notu kaydet";
$WriteYourNoteHere = "Buraya t&#305;klayarak yeni not yaz&#305;n";
$SearchByTitle = "Ba&#351;l&#305;&#287;a göre ara";
$WriteTheTitleHere = "Ba&#351;l&#305;&#287;&#305; buraya yaz&#305;n";
$UpdateDate = "Son güncelleme";
$NoteAddNew = "Defterime not ekle";
$OrderByCreationDate = "Olu&#351;turma tarihine göre";
$OrderByModificationDate = "Son güncelleme tarihine göre";
$OrderByTitle = "Ba&#351;l&#305;&#287;a göre";
$NoteTitle = "Not ba&#351;l&#305;&#287;&#305;";
$NoteComment = "Not detaylar&#305;";
$NoteAdded = "Not eklendi";
$NoteConfirmDelete = "Notu silmek istiyor musunuz ?";
$AddNote = "Not olu&#351;tur";
$ModifyNote = "Ki&#351;isel notlar&#305;m&#305; düzenle";
$BackToNoteList = "Not listesine geri dön";
$NotebookManagement = "Not Defteri yönetimi";
$BackToNotesList = "Not listesine geri dön";
$NotesSortedByTitleAsc = "Notlar&#305; ba&#351;l&#305;&#287;a göre s&#305;rala (A-Z)";
$NotesSortedByTitleDESC = "Notlar&#305; ba&#351;l&#305;&#287;a göre s&#305;rala (Z-A)";
$NotesSortedByUpdateDateAsc = "Notlar&#305; güncelleme tarihine göre s&#305;rala (1-9)";
$NotesSortedByUpdateDateDESC = "Notlar&#305; güncelleme tarihine göre s&#305;rala (9-1)";
$NotesSortedByCreationDateAsc = "Notlar&#305; olu&#351;turma tarihine göre s&#305;rala (1-9)";
$NotesSortedByCreationDateDESC = "Notlar&#305; güncelleme tarihine göre s&#305;rala (9-1)";
?>