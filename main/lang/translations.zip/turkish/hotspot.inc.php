<?php
/*
for more information: see languages.txt in the lang folder.
*/
$select = "Geçerli k&#305;l";
$square = "Kare";
$circle = "Elips";
$poly = "Çokgen";
$status1 = "Hotspot çizin";
$status2_poly = "Çokgeni kapatmak için sa&#287; tu&#351;a bas&#305;n";
$status2_other = "Hotspotu kaydetmek için farenin tu&#351;unu b&#305;rak&#305;n";
$status3 = "Hotspot kaydedildi";
$exercise_status_1 = "A&#351;a&#287;&#305;daki resme t&#305;klayarak cevaplay&#305;n";
$exercise_status_2 = "Cevaplar&#305; geçerli k&#305;l";
$exercise_status_3 = "Durum: Sorudan vazgeçildi";
$showUserPoints = "Kullan&#305;c&#305; t&#305;klamalar&#305;n&#305; Göster/Gizle";
$showHotspots = "Hotspotlar&#305; göster/gizle";
$labelPolyMenu = "Çokgeni kapat";
$triesleft = "Kalan denemeler";
$exeFinished = "Cevab&#305;n&#305;z&#305;n geçerli olmas&#305; için a&#351;a&#287;&#305;daki tu&#351;u &#351;imdi t&#305;klay&#305;n&#305;z";
$nextAnswer = "&#350;imdi yap&#305;ld&#305;ya t&#305;klay&#305;n&#305;z";
$delineation = "Çizim";
$labelDelineationMenu = "Çizimi kapat";
$oar = "Riskli alan";
?>