<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langClarContent = "<p><b>Teacher</b></";
$test = "testas";
$WCAGImage = "Paveikslėlis";
$WCAGLabel = "Paveikslėlio pavadinimas";
$WCAGLink = "Nuoroda";
$WCAGLinkLabel = "Nuorodos pavadinimas";
$errorNoLabel = "Paveikslėlis neturi pavadinimo.";
$AllLanguages = "visos kalbos";
$WCAGEditor = "WCAG teksto redaktorius";
$WCAGGoMenu = "Meniu";
$WCAGGoContent = "Turinys";
?>