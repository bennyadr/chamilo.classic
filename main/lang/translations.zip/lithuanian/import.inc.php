<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langPgTitle = "Puslapio antraštė";
$langExplanation = "Puslapis turi būti HTML formato (pvz. \\"my_page.htm\\"). Tituliniame bus nuoroda į jį. Jei norite įkelti ne HTML formato failus (PDF, Word, Power Point, Video, etc.) naudokite <a href=../document/document.php>Dokumentų įrankį</a>";
$langTooBig = "Nepasirinkote jokio failo įkėlimui, arba jis yra per didelis.";
$langCouldNot = "Šio failo įkelti negalima.";
$langNotAllowed = "Neleidžiama";
$langAddPageToSite = "Įrašyti puslapį į sritį";
$langCouldNotSendPage = "Šis failas nėra HTML formato ir negali būti įkeliamas. Jei norite įkelti ne HTML formato failus (PDF, Word, Power Point, Video, etc.) naudokite <a href=../document/document.php>Dokumentų įrankį</a>";
$langSendPage = "Įkeliamas puslapis";
$langPageTitleModified = "Puslapio antraštė modifikuota";
$langPageAdded = "Puslapis įterptas";
$langAddPage = "Įterpti puslapį";
$Choose = "";
?>