<?php
/*
for more information: see languages.txt in the lang folder.
*/
$nameTools = "nebevartojamas kalbos kintamasis";
$langMdCallingTool = "Mokymosi medžiaga - Scorm";
$langTool = "Scorm MD Operacijos";
$langNotInDB = "no Chamilo DB entry";
$langManifestSyntax = "(syntax error in manifest file...)";
$langEmptyManifest = "(empty manifest file...)";
$langNoManifest = "(no manifest file...)";
$langNotFolder = "neįmanoma, tai ne katalogas...";
$langUploadHtt = "Įkelti HTT failą";
$langHttFileNotFound = "Naujas HTT failas negali būti atidarytas (pvz. tuščias, per didelis)";
$langHttOk = "Naujas HTT failas įkeltas";
$langHttNotOk = "HTT failo įkrovimas napavyko";
$langRemoveHtt = "Ištrinti HTT failą";
$langHttRmvOk = "HTT failas ištrintas";
$langHttRmvNotOk = "HTT failo ištrynimas nepavyko";
$langImport = "Sukurti MDEs iš manifest failo";
$langRemove = "Pašalinti MDEs";
$langAllRemovedFor = "Visi įrašai pašalinti";
$langIndex = "Index Words with PhpDig";
$langTotalMDEs = "Iš viso Scorm MD įaršų:";
$langMainMD = "Atidaryti pagrindinį MDE";
$langLines = "eilutės";
$langPlay = "Paleisti index.php";
$langNonePossible = "MD operacijos negalimos";
$langOrElse = "Parinkti Scorm katalogą arba Scorm katalogo ID";
$langWorkWith = "Darbas su Scorm katalogu";
$langSDI = "... Scorm Directory with SD-id (and split manifest - or leave empty)";
$langRoot = "root";
$langSplitData = "Split manifests, and #MDe, if any:";
$langMffNotOk = "Manifest file replace has failed";
$langMffOk = "Manifest file has been replaced";
$langMffFileNotFound = "New manifest file could not be opened (e.g. empty, too big)";
$langUploadMff = "Replace manifest file";
?>