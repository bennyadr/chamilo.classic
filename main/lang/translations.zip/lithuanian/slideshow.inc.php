<?php
/*
for more information: see languages.txt in the lang folder.
*/
$lang_height = "Aukštis";
$lang_resizing_comment = "resize the image to the following dimensions (in pixels)";
$lang_width = "Plotis";
$lang_resizing = "Keisti dydį";
$lang_no_resizing_comment = "Show all images in their original size. No resizing is done. Scrollbars will automatically appear if the image is larger than your monitor size.";
$lang_show_thumbnails = "Show Thumbnails";
$lang_click_thumbnails = "Click on one of the thumbnails";
$lang_set_slideshow_options = "Set Slideshow Options";
$lang_slideshow_options = "Skaidrių nustatymai";
$lang_no_resizing = "Nekeisti dydžio (default)";
$lang_exit_slideshow = "Išeiti";
$SlideShow = "Skaidrės";
$lang_previous_slide = "Buvusi skaidrė";
$lang_next_slide = "Kita skaidrė";
$lang_image = "Paveikslėlis";
$lang_of = "išjungta";
$lang_view_slideshow = "Rodyti skaidres";
$FirstSlide = "";
$LastSlide = "";
?>