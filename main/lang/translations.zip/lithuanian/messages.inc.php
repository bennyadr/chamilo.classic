<?php
/*
for more information: see languages.txt in the lang folder.
*/
$MessageEmptyMessageOrSubject = "";
$Inbox = "Priėmimo dėžutė";
$Messages = "Žinutės";
$SendMessage = "Siūsti žinutę";
$NewMessage = "Nauja žinutė";
$ComposeMessage = "Rašyti žinutę";
$DeleteSelectedMessages = "Ištrinti pasirinktas žinutes";
$SelectAll = "Pažymėti visas";
$DeselectAll = "Atžymėti visas";
$ReplyToMessage = "Atsakyti";
$BackToInbox = "Atgal į priėmimo dėžutę";
$MessageSentTo = "Žinutė išsiųsta";
$SendMessageTo = "Siųsti kam";
$Myself = "man";
$From = "Nuo";
$To = "Kam";
$Date = "Data";
$InvalidMessageId = "Žinutė, į kurią norima atsakyti, neegzistuoja.";
$ErrorSendingMessage = "Klaida bandant išsiųsti žinutę.";
$SureYouWantToDeleteSelectedMessages = "Ar tikrai norite ištrinti pažymėtas žinutes?";
$SelectedMessagesDeleted = "The selected messages have been deleted";
$EnterTitle = "";
$TypeYourMessage = "";
$MessageDeleted = "";
$ConfirmDeleteMessage = "";
$DeleteMessage = "";
$ReadMessage = "";
$SendInviteMessage = "";
$SendMessageInvitation = "";
$MessageTool = "";
$WriteAMessage = "";
$AlreadyReadMessage = "";
$UnReadMessage = "";
$MessageSent = "";
$YouShouldWriteAMessage = "";
?>