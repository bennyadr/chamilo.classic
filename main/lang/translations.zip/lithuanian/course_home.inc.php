<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langActivate = "Rodyti";
$langDeactivate = "Slėpti";
$langInLnk = "Paslėpti įrankiai ir nuorodos";
$langDelLk = "Ar tikrai norite ištrinti šią nuorodą?";
$langCourseCreate = "Sukurti kurso tinklapį";
$langNameOfTheLink = "Nuorodos pavadinimas";
$lang_main_categories_list = "Pagrindinis kategorijų sąrašas";
$langCourseAdminOnly = "tik dėstytojams";
$PlatformAdminOnly = "tik sistemos administratoriams";
$langCombinedCourse = "Kombinuotas kursas";
$ToolIsNowVisible = "Įrankis nuo šiol matomas.";
$ToolIsNowHidden = "Įrankis nuo šiol nematomas.";
$EditLink = "Redaguoti nuorodą";
$Blog_management = "Dienoraščių tvarkymas";
$Forum = "Forumai";
$Course_maintenance = "Kurso aptarnavimas";
$TOOL_SURVEY = "Apžvalgos";
$GreyIcons = "Įrankų juosta";
$Interaction = "Veikla";
$Authoring = "Kūrimas";
$Administration = "Administravimas";
$IntroductionTextUpdated = "Paaiškinamasis tekstas atnaujintas";
$IntroductionTextDeleted = "Introduction text deleted";
$SessionIdentifier = "";
$SessionName = "";
$SessionCategory = "";
$SessionData = "";
?>