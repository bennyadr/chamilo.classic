<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langTool = "Meta duomenys";
$langClickKw = "Click a keyword in the tree to select or deselect it.";
$langKwHelp = "<br";
$langAdvanced = "Išplėstinis";
$langSearch = "Paieška";
$langSearchCrit = "Use the area below for descriptive words, one word per line!";
$langNoKeywords = "Šis kursas neturi raktažodžių";
$langKwCacheProblem = "The keyword cache cannot be opened";
$langCourseKwds = "kurso raktažodžiai";
$langKwdsInMD = "raktažodžiai, naudojami MD";
$langKwdRefs = "keyword references";
$langNonCourseKwds = "Non-course keywords";
$langKwdsUse = "Kurso raktažodžiai (bold = not used)";
$langTotalMDEs = "Iš viso MD įrašų:";
?>