<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langViewCourseMaterialImport = "Peržiūrėti importuojamą kursų medžiagą";
$langViewExternalLinksImport = "Peržiūrėti importuojamas išorines nuorodas";
$langViewForumImport = "Peržiūrėti importuojamą forumą";
$langImportCourseMaterial = "Importuoti kursų medžiagą (Blackboard įrankis \\"Kursų medžiaga\\")";
$langImportExternalLinks = "Importuoti nuorodas (Blackboard įrankis \\"Išorinės nuorodos\\")";
$langImportForum = "Importuoti forumus (Blackboard įrankis \\"Diskusijų lenta\\")";
$langToolInfo = "Šis įrankis importuoja Blackboard 5.5 kursus (Teorinę kursų medžiagą, Diskusijas ir išorines nuorodas)";
$langToolName = "Importuoti Blackboard kursą";
$langSelectCoursePackage = "Išrinkti kursų archyvą";
$langPackageAlreadySelected = "Jūs jau parinkote archyvą importavimui";
$langFirstSelectPackage = "Pirmiausia turite parinkti ir atidaryti archyvą prieš importavimą.";
$langCourseToMigrate = "Keliamas kursas";
$langSelectPackage = "Parinkti archyvą";
$langOpenPackageForImporting = "Atidaryti archyvą importavimui";
$langInformation = "Informacija apie importą";
$langChooseImportOptions = "Pasirinkite importo nustatymus";
$langCheckWhatIsImported = "Jūs galite peržiūrėti, kas bus importuota";
$langStartImporting = "Pradėti importavimą";
$langImport = "Importuoti";
?>