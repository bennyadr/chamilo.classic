<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langScormBuilder = "Path builder - Scorm formato kursų kūrimo įrankis";
?>