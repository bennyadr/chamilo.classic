<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langCourseProgram = "Kurso aprašymas";
$langThisCourseDescriptionIsEmpty = "Šis kursas dar neaprašytas.";
$langEditCourseProgram = "Sukurti ir redaguoti kurso aprašymą";
$QuestionPlan = "Pagalbiniai klausimai kūrėjui";
$langInfo2Say = "Informacija vartotojams";
$langOuAutreTitre = "Antraštė";
$langNewBloc = "Kita";
$langAddCat = "įrašyti kategoriją";
$langAdd = "Įrašyti";
$langValid = "Galiojantis";
$langBackAndForget = "Back and forget";
$CourseDescriptionUpdated = "Kurso aprašymas atnaujintas";
$CourseDescriptionDeleted = "Kurso aprašymas ištrintas";
$CourseDescriptionIntro = "Kad sukurti kurso aprašymą, spustelėkite ant ikonos, teisingai užpildykite formą.";
$langSaveDescription = "";
?>