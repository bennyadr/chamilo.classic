<?php
/*
for more information: see languages.txt in the lang folder.
*/
$lang_new_item = "naujas įrašas įdėtas";
$lang_title_notification = "Nuo Jūsų paskutinio vizito";
$lang_update_agenda = "esamas darbotvarkės įrašas atnaujintas";
$lang_new_agenda = "esamas darbotvarkės įrašas įdėtas";
$lang_update_announcements = "esamas skelbimas atnaujintas";
$lang_new_announcements = "esamas skelbimas įdėtas";
$lang_new_document = "naujas dokumentas įdėtas";
$lang_new_exercise = "naujas pratimas įjungtas";
$lang_update_link = "esama nuorodos informacija atnaujinta";
$lang_new_link = "nauja nuoroda įdėta";
$lang_new_forum_topic = "nauja tema įrašyta";
$lang_new_groupforum_topic = "grupės forume įrašyta nauja tema";
$lang_new_dropbox_file = "gautas naujas failas";
$lang_update_dropbox_file = "Jūsų failų saugykloje esantis failas atnaujintas";
$ForumCategoryAdded = "Forum category added";
$LearnpathAdded = "";
$GlossaryAdded = "";
$QuizQuestionAdded = "";
$QuizQuestionUpdated = "";
$QuizQuestionDeleted = "";
$QuizUpdated = "";
$QuizAdded = "";
$QuizDeleted = "";
$DocumentInvisible = "";
$DocumentVisible = "";
$CourseDescriptionAdded = "";
$WikiAdded = "";
$SurveyAdded = "";
$NotebookAdded = "";
$NotebookUpdated = "";
$NotebookDeleted = "";
?>