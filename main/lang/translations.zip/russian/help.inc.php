<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langHFor = "Форумы помощи";
$langForContent = "Форум написан в виде не синхронизированной дискуссии. В то время как переписка по Эл. почте позволяет диалог один на один, на форуме возможен публичный или частично публичный диалог.</p><p>Говоря технически, пользователям нужен только их браузер, чтобы ис";
$langHDropbox = "Ящик для содержимого";
$langDropboxContent = "<p>Ящик для содержимого – это инструмент управления содержимым, посвящен обмену данными между равными. Любой тип файла принимается: Word, Excel, PDF etc. Он будет управлять версиями, в том смысле, что поможет избежать уничтожения документа другим документ";
$langHHome = "Помощь на Домашней странице курса";
$langHomeContent = "<p>Домашняя страница курса содержит набор инструментов: введение, описание курса, управление документами и т.д. Эта страница состоит из модулей: вы можете скрывать/показывать любой инструмент с помощью одного щелчка. Скрытые инструменты могут быть активиз";
$langHOnline = "Помощь системе проведения конференций в прямом эфире";
$langOnlineContent = "<br><span style=\\"font-weight: bold;\\">Введение </span><br> <br> <div style=\\"margin-left: 40px;\\">Система проведения конференции в прямом эфире программы Докеос позволяет Вам обучать, информировать или объединять между собой до 500 человек простым и быст";
$langHClar = "Помощь Докеос";
$langHDoc = "Помощь при работе с документами";
$langDocContent = "";
$langHUser = "Помощь пользователям";
$langHExercise = "Помощь к тестам";
$langHPath = "Помощь к учебному плану";
$langHDescription = "Помощь в описании курса";
$langHLinks = "Помощь к инструментам Ссылок";
$langHMycourses = "О начальной (стартовой) странице";
$langHAgenda = "Помощь по Повестке дня";
$langHAnnouncements = "Помощь по Объявлениям";
$langHChat = "Помощь по Чату";
$langHWork = "Помощь по Публикациям студента";
$langHTracking = "Помощь по Отслеживанию";
$langUserContent = "";
$langGroupContent = "";
$langExerciseContent = "";
$langPathContent = "";
$langDescriptionContent = "";
$langLinksContent = "";
$langMycoursesContent = "";
$langAgendaContent = "";
$langAnnouncementsContent = "";
$langChatContent = "";
$langWorkContent = "";
$langTrackingContent = "";
$langHSettings = "Помощь при настройках курса";
$langSettingsContent = "";
$langHExternal = "Помощь при добавлении ссылки";
$langExternalContent = "";
$langClarContent3 = "Очистить от содержимого";
$langClarContent4 = "Очистить от содержимого";
$langClarContent1 = "Очистить от содержимого";
$langClarContent2 = "Очистить от содержимого";
$langHGroups = "Группы";
$langGroupsContent = "Содержимое групп";
$langGuide = "Руководство";
$HSurvey = "";
$SurveyContent = "";
$HBlogs = "";
$BlogsContent = "";
?>