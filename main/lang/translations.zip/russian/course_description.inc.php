<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langCourseProgram = "Описание курса";
$langThisCourseDescriptionIsEmpty = "Этот курс еще не описан";
$langEditCourseProgram = "Создать и редактировать описание курса";
$QuestionPlan = "Вопросы для преподавателя";
$langInfo2Say = "Информация для пользователей";
$langOuAutreTitre = "Название";
$langNewBloc = "Другое";
$langAddCat = "добавить раздел";
$langAdd = "Добавить";
$langValid = "Подтвердить";
$langBackAndForget = "Отменить";
$CourseDescriptionUpdated = "Описание курса обновлено";
$CourseDescriptionDeleted = "Описание курса удалено";
$CourseDescriptionIntro = "Для того, чтобы создать описание курса, щелкните на заголовок и заполните необходимые поля формы.<br><br> Затем щелкните ОК и заполните другой заголовок.";
$langSaveDescription = "";
?>