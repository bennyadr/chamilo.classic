<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langScormBuilder = "Строитель Плана - строитель курса в формате Scorm";
?>