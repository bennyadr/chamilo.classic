<?php
/*
for more information: see languages.txt in the lang folder.
*/
$lang_height = "Высота";
$lang_resizing_comment = "изменить размер изображения до следующих размеров (в пикселях)";
$lang_width = "Ширина";
$lang_resizing = "ИЗМЕНИТЬ РАЗМЕРЫ";
$lang_no_resizing_comment = "Показать все изображения в их истинных размерах. Изменения размеров не выполнено. Управляющая линейка с бегунком появиться автоматически, если изображение превысит размеры монитора.";
$lang_show_thumbnails = "Показать контрольные изображения";
$lang_click_thumbnails = "Щелкнуть по одному из контрольных изображений";
$lang_set_slideshow_options = "Задать настройки Показа слайдов";
$lang_slideshow_options = "Настройки Показа слайдов";
$lang_no_resizing = "НЕ ИЗМЕНЯТЬ РАЗМЕРЫ (по умолчанию)";
$lang_exit_slideshow = "Выйти из Показа слайдов";
$SlideShow = "Показ слайдов";
$lang_previous_slide = "Предыдущий слайд";
$lang_next_slide = "Следующий слайд";
$lang_image = "Изображение";
$lang_of = " о, об, из, от...";
$lang_view_slideshow = "Просмотр Показа слайдов";
$FirstSlide = "";
$LastSlide = "";
?>