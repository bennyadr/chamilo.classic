<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langPgTitle = "Заголовок страницы";
$langExplanation = "Эта страница должна быть в HTML формате (например \\"моя_страница.htm\\"). На нее можно будет попасть с Домашней страницы. Если Вы хотите послать документы в другом формате (PDF, Word, Power Point, Video, etc.) используйте <a href=../document/document.php>Д";
$langTooBig = "Вы не выбрали ни одного файла для загрузки или он слишком большой.";
$langCouldNot = "Файл не может быть загружен";
$langNotAllowed = "Не разрешено";
$langAddPageToSite = "Добавить страницу в зону";
$langCouldNotSendPage = "Эта страница должна быть в HTML формате (например \\"моя_страница.htm\\"). На нее можно будет попасть с Домашней страницы. Если Вы хотите послать документы в другом формате (PDF, Word, Power Point, Video, etc.) используйте <a href=../document/document.php>Д";
$langSendPage = "Страница для загрузки";
$langPageTitleModified = "Заголовок страницы изменен";
$langPageAdded = "Страница добавлена";
$langAddPage = "Добавить страницу";
$Choose = "";
?>