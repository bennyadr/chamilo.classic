<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langActivate = "Активировать";
$langDeactivate = "Сделать неактивным";
$langInLnk = "Сделать неактивными инструменты и ссылки";
$langDelLk = "Вы действительно хотите удалить эту ссылку?";
$langCourseCreate = "Создать вебсайт курса";
$langNameOfTheLink = "Название ссылки";
$lang_main_categories_list = "Основной список разделов";
$langCourseAdminOnly = "Толь для преподавателей";
$PlatformAdminOnly = "Только для администраторов платформы";
$langCombinedCourse = "Объединенный курс";
$ToolIsNowVisible = "Инструмент сейчас видим (активен)";
$ToolIsNowHidden = "Инструмент сейчас не активен";
$EditLink = "Редактировать ссылку";
$Blog_management = "Управление блогами";
$Forum = "Форумы";
$Course_maintenance = "Поддержание курса";
$TOOL_SURVEY = "Анкетирование";
$GreyIcons = "Инструменты";
$Interaction = "Взаимодействие";
$Authoring = "Авторские документы";
$Administration = "Администрация";
$IntroductionTextUpdated = "Введение обновлено";
$IntroductionTextDeleted = "Введение удалено";
$SessionIdentifier = "";
$SessionName = "";
$SessionCategory = "";
$SessionData = "";
?>