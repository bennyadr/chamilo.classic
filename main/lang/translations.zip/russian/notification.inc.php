<?php
/*
for more information: see languages.txt in the lang folder.
*/
$lang_new_item = "новый пункт добавлен";
$lang_title_notification = "С момента Вашего последнего визита";
$lang_update_agenda = "существующие пункты повестки дня обновлены";
$lang_new_agenda = "новый пункт повестки дня добавлен";
$lang_update_announcements = "существующее объявление обновлено";
$lang_new_announcements = "новое объявление добавлено";
$lang_new_document = "новый(е) документ(ы) добавлен(ы)";
$lang_new_exercise = "новое упражнение задействовано";
$lang_update_link = "существующая информация о ссылке обновлена";
$lang_new_link = "новая ссылка добавлена";
$lang_new_forum_topic = "новая тема добавлена";
$lang_new_groupforum_topic = "новая форма добавлена в форум группы";
$lang_new_dropbox_file = "новый файл получен";
$lang_update_dropbox_file = "файл в Вашем ящике для сообщений обновлен";
$ForumCategoryAdded = "Раздел форума добавлен";
$LearnpathAdded = "Учебный план добавлен";
$GlossaryAdded = "";
$QuizQuestionAdded = "";
$QuizQuestionUpdated = "";
$QuizQuestionDeleted = "";
$QuizUpdated = "";
$QuizAdded = "";
$QuizDeleted = "";
$DocumentInvisible = "";
$DocumentVisible = "";
$CourseDescriptionAdded = "";
$WikiAdded = "";
$SurveyAdded = "";
$NotebookAdded = "";
$NotebookUpdated = "";
$NotebookDeleted = "";
?>