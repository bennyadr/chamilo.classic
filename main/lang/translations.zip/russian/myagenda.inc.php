<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langMyAgenda = "Мой порядок дня (расписание)";
$langToday = "Сегодня";
?>