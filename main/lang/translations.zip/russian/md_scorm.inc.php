<?php
/*
for more information: see languages.txt in the lang folder.
*/
$nameTools = "устаревшая языковая переменная";
$langMdCallingTool = "Учебный план - Scorm";
$langTool = "Действия Scorm МД (метаданные)";
$langNotInDB = "нет входа в БД (база данных) Докеос";
$langManifestSyntax = "(синтаксическая ошибка в манифестном файле...)";
$langEmptyManifest = "(пустой манифестный файл...)";
$langNoManifest = "(манифестного файла нет...)";
$langNotFolder = "невозможно, это не папка...";
$langUploadHtt = "Загрузить HTT файл";
$langHttFileNotFound = "Новый HTT файл не открывается (может быть пустой или слишком большой)";
$langHttOk = "Новый HTT файл загружен";
$langHttNotOk = "Ошибка при загрузке HTT файла";
$langRemoveHtt = "Удалить HTT файл";
$langHttRmvOk = "HTT файл был удален";
$langHttRmvNotOk = "Ошибка при удалении HTT файла";
$langImport = "Создать MDE (метаданные) из манифеста";
$langRemove = "Удалить MDE (метаданные)";
$langAllRemovedFor = "Все вводы удалены для";
$langIndex = "Индексирование Word с PhpDig";
$langTotalMDEs = "Ощее число Scorm MD вводов (записей):";
$langMainMD = "Открыть Главную запись с метаданными";
$langLines = "строки";
$langPlay = "Начать действие файла индекс.php";
$langNonePossible = "Никакие действия с метаданными невозможны";
$langOrElse = "Выбрать Раздел Scorm или Раздел Scorm id";
$langWorkWith = "Работать с Разделом Scorm";
$langSDI = "... Раздел Scorm с Разделом Scorm-id (и разделить манифест - или оставить пустым)";
$langRoot = "корень";
$langSplitData = "Разделить манифесты, и № метаданных, если это имеет место:";
$langMffNotOk = "Замена манифестного файла не удалась";
$langMffOk = "Манифестный файл заменен";
$langMffFileNotFound = "Новый манифестный файл не открывается (может быть пустой или слишком большой)";
$langUploadMff = "Заменить манифестный файл";
?>