<?php
/*
for more information: see languages.txt in the lang folder.
*/
$MessageEmptyMessageOrSubject = "";
$Inbox = "Входящие";
$Messages = "Сообщения";
$SendMessage = "Отправить сообщение";
$NewMessage = "Новое сообщение";
$ComposeMessage = "Написать сообщение";
$DeleteSelectedMessages = "Удалить выделенные сообщения";
$SelectAll = "Выбрать все";
$DeselectAll = "Отменить выбор всех";
$ReplyToMessage = "Ответить";
$BackToInbox = "Вернуться во входящие";
$MessageSentTo = "Сообщение отправлено";
$SendMessageTo = "Отправить";
$Myself = "себе";
$From = "От";
$To = "Кому";
$Date = "Дата";
$InvalidMessageId = "ID ответного сообщения не действительно";
$ErrorSendingMessage = "Произошла ошибка при отправлении сообщения";
$SureYouWantToDeleteSelectedMessages = "Вы уверены, что хотите удалить выбранные сообщения?";
$SelectedMessagesDeleted = "Выбранные сообщения удалены";
$EnterTitle = "";
$TypeYourMessage = "";
$MessageDeleted = "";
$ConfirmDeleteMessage = "";
$DeleteMessage = "";
$ReadMessage = "";
$SendInviteMessage = "";
$SendMessageInvitation = "";
$MessageTool = "";
$WriteAMessage = "";
$AlreadyReadMessage = "";
$UnReadMessage = "";
$MessageSent = "";
$YouShouldWriteAMessage = "";
?>