<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langClarContent = "ПреподавательDokeos – это система управления обучением и знаниями. Она позволяет преподавателю организовывать обучающие материалы, обучающую стратегию и управлять взаимодействием со своими студентами. Все это осуществляется через веб-браузер.Для того, что";
$test = "тест";
$WCAGImage = "Изображение";
$WCAGLabel = "Подпись изображения";
$WCAGLink = "Ссылка";
$WCAGLinkLabel = "Подпись ссылки";
$errorNoLabel = "Нет подписи рисунка";
$AllLanguages = "все языки";
$WCAGEditor = "Редактор WCAG";
$WCAGGoMenu = "Перейти к меню";
$WCAGGoContent = "Перейти к содержанию";
?>