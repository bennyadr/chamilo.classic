<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langScormVersion = "wersja";
$langScormRestarted = "Wszystkie lekcje s&#261; teraz niekompletne.";
$langScormNoNext = "To jest ostatnia lekcja.";
$langScormNoPrev = "To jest pierwsza lekcja.";
$langScormTime = "Czas";
$langScormNoOrder = "Nie ma zadanego porz&#261;dku. Mo&#380;esz zacz&#261;&#263; w dowolnym miejscu.";
$langScormScore = "Wynik";
$langScormLessonTitle = "Temat lekcji";
$langScormStatus = "Status";
$langScormToEnter = "Aby wej&#347;&#263;";
$langScormFirstNeedTo = "najpierw musisz uko&#324;czy&#263;";
$langScormThisStatus = "Ta lekcja jest teraz";
$langScormClose = "Zako&#324;cz";
$langScormRestart = "Zacznij od pocz&#261;tku";
$langScormCompstatus = "Uko&#324;czono";
$langScormIncomplete = "Nie uko&#324;czono";
$langScormPassed = "Zaliczony";
$langScormFailed = "Niezaliczony";
$langScormPrevious = "Poprzedni";
$langScormNext = "Nast&#281;pny";
$langScormTitle = "Gracz Chamilo Scorm";
$langScormMystatus = "Mój status";
$langScormNoItems = "Nie ma tu &#380;adnych elementów.";
$langScormNoStatus = "Ta zawarto&#347;&#263; nie posiada statusu";
$langScormLoggedout = "Wylogowany(-a) z obszaru Scorm";
$langScormCloseWindow = "Zamknij okna";
$ScormBrowsed = "";
$langScormExitFullScreen = "Powrót do standardowego ekranu";
$langScormFullScreen = "pe&#322;ny ekran";
$langScormNotAttempted = "Nie próbowano";
$langCharset = "";
$langLocal = "";
$langRemote = "";
$langAutodetect = "";
$langAccomplishedStepsTotal = "";
$langUnknown = "";
$AreYouSureToDeleteSteps = "";
$Origin = "";
$Local = "";
$Remote = "";
$FileToUpload = "";
$ContentMaker = "";
$ContentProximity = "";
$UploadLocalFileFromGarbageDir = "";
$ThisItemIsNotExportable = "";
$MoveCurrentChapter = "";
$GenericScorm = "";
$UnknownPackageFormat = "";
$Attempt = "";
$MoveTheCurrentForum = "";
$WarningWhenEditingScorm = "";
$AdditionalProfileField = "";
?>