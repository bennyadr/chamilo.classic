<?php
/*
for more information: see languages.txt in the lang folder.
*/
$nameTools = "przestarza&#322;a zmienna j&#281;zykowa";
$langMdCallingTool = "&#346;cie&#380;ka nauki - Scorm";
$langTool = "Operacje MD Scorm";
$langNotInDB = "wpis niezgodny z DB Chamilo\'a";
$langManifestSyntax = "(b&#322;&#261;d sk&#322;adni w pliku...)";
$langEmptyManifest = "(pusty plik...)";
$langNoManifest = "(brak pliku...)";
$langNotFolder = "nie s&#261; mo&#380;liwe, to nie jest katalog...";
$langUploadHtt = "Za&#322;aduj plik HTT";
$langHttFileNotFound = "Nie mo&#380;na by&#322;o otworzy&#263; nowego pliku HTT (np. pusty, zbyt du&#380;y)";
$langHttOk = "Nowy plik HTT zosta&#322; za&#322;adowany";
$langHttNotOk = "Za&#322;adowanie pliku HTT nie powiod&#322;o si&#281;";
$langRemoveHtt = "Usu&#324; plik HTT";
$langHttRmvOk = "Plik HTT zosta&#322; usuni&#281;ty";
$langHttRmvNotOk = "Usuni&#281;cie pliku HTT nie powiod&#322;o si&#281;";
$langImport = "Utwórz MDE z pokazanego";
$langRemove = "Usu&#324; MDE";
$langAllRemovedFor = "Wszystkie wpisy usuni&#281;te z powodu";
$langIndex = "Indeksuj s&#322;owa za pomoc&#261; PhpDig";
$langTotalMDEs = "Ogólna liczba wpisów Scorm MD";
$langMainMD = "Otwórz g&#322;owny MDE";
$langLines = "linie";
$langPlay = "Uruchom index.php";
$langNonePossible = "Nie mo&#380;na wykona&#263; &#380;adnych operacji MD";
$langOrElse = "Wybierz katalog Scorm";
$langWorkWith = "Pracuj z katalogiem Scorm";
$langSDI = "... Katalog Scrom z id-Katalogu Scorm (i podziel pokazany - albo zostaw pusty)";
$langRoot = "root";
$langSplitData = "Podziel pokazany, i liczb&#281; wpisów MDE, w przypadku:";
$langMffNotOk = "Zamiana pokazanego pliku nie powiod&#322;a si&#281;";
$langMffOk = "Pokazany plik zaosta&#322; zamieniony";
$langMffFileNotFound = "Nowy pokazany plik nie móg&#322; zosta&#263; otwarty (np. pusty, za du&#380;y)";
$langUploadMff = "Zamie&#324; pokazany plik";
?>