<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langScormBuilder = "Narz&#281;dzie do budowy &#347;cie&#380;ek - narz&#281;dzie do budowy kursów w formacie Scorm";
?>