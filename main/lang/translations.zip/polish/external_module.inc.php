<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langLinkSite = "Odno&#347;nik do strony";
$langSubTitle = "Dodanie odno&#347;nika do zewn&#281;trzego adresu URL na Stronie g&#322;ównej kursu. Uwaga: Je&#347;li chcesz pod&#322;&#261;czy&#263; jak&#261;&#347; stron&#281; z Internetu, wejd&#378; na t&#281; stron&#281;, skopiuj jej adres z pola Adres okienka przeg";
$langAddPage = "Dodaj stron&#281;";
$langSendPage = "Strona do wys&#322;ania";
$langCouldNot = "Plik nie mo¿e byæ przes³any";
$langOkSentLink = "Odno&#347;nik &#380;osta&#322; dodany.<p>Jest on dost&#281;pny ze <a href=\\"../../DOKEOSDEV/index.php\\">strony g&#322;ównej kursu</a>";
$langTooBig = "Nie wybrano &#380;adnego pliku do wys&#322;ania lub jest on za du&#380;y";
$langExplanation = "Strona musi byæ plikiem HTML (np. \\"my_page.htm\\"). B&#281;dzie ona dostêpna jako odno&#347;nik ze strony g&#322;ównej. Je&#347;li chcesz wys&#322;a&#263; dokument w innym formacie (PDF, Word, Power Point, Video, etc.) u&#380;yj <a href=../document/docume";
$langPgTitle = "Tytu&#322; strony";
$langNoLinkURL = "Wprowad&#378; adres &#322;&#261;cza (URL)";
$langLinkTarget = "Cel &#322;&#261;cza";
$langSameWindow = "W tym samym oknie";
$langNewWindow = "W nowym oknie";
$langAdded = "&#321;&#261;cze zosta&#322;o dodane";
$langAddLink = "Dodaj odno¶nik";
$langNoLinkName = "Podaj nazw&#281; dla &#322;&#261;cza";
$langEditLink = "Edytuj &#322;&#261;cze do strony g&#322;ównej kursu";
$langChangePress = "";
$langLinkChanged = "";
$NoLinkName = "";
$NoLinkURL = "";
$LinkChanged = "";
$OkSentLink = "";
?>