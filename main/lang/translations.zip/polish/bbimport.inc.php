<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langViewCourseMaterialImport = "Zobacz materia&#322; kursu, jaki b&#281;dzie importowany";
$langViewExternalLinksImport = "Zobacz linki zewn&#281;trzne, jakie b&#281;d&#261; importowane";
$langViewForumImport = "Wy&#347;wietl forum, jakie b&#281;dzie importowane";
$langImportCourseMaterial = "Importuj materia&#322; kursu (Blackboard tool \\"Course Material\\")";
$langImportExternalLinks = "Importuj linki zewn&#281;trzne (Blackboard tool \\"External Links\\")";
$langImportForum = "Importuj forum (Blackboard tool \\"Discussion Board\\")";
$langToolInfo = "To narz&#281;dzie importuje tablic&#281; (Blackboard 5.5) kursu (Materia&#322; kursu, Forum dyskusyjne, Linki zewn&#281;trzne)";
$langToolName = "Importuj kursy (Blackboard)";
$langSelectCoursePackage = "Wybierz pakiet kursu";
$langPackageAlreadySelected = "Ju&#380; wybra&#322;e&#347; pakiet";
$langFirstSelectPackage = "Najpierw trzeba wybra&#263; pakiet i otworzy&#263; go, zanim b&#281;dzie mo&#380;na przyst&#261;pi&#263; do importu.";
$langCourseToMigrate = "Kurs do migracji";
$langSelectPackage = "Wybierz pakiet";
$langOpenPackageForImporting = "Otwórz pakiet do importu";
$langInformation = "Informacje na temat procesu importu";
$langChooseImportOptions = "Wybierz opcj&#281; importu";
$langCheckWhatIsImported = "Mo&#380;esz sprawdzi&#263;, jakie dane b&#281;d&#261; importowane przed rozpocz&#281;ciem procesu importowania";
$langStartImporting = "Rozpocznij import";
$langImport = "Importuj";
?>