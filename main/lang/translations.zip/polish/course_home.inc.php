<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langActivate = "aktywuj";
$langDeactivate = "deaktywuj";
$langInLnk = "Nieaktywne &#322;&#261;cza";
$langDelLk = "Czy rzeczywi&#347;cie chcesz usun&#261;&#263; ten odno&#347;nik?";
$langCourseCreate = "Utwórz nowy kurs";
$langNameOfTheLink = "Nazwa odno&#347;nika";
$lang_main_categories_list = "Lista Wydzia³ów/kategorii";
$langCourseAdminOnly = "Tylko dla prowadz&#261;cych";
$PlatformAdminOnly = "Tylko dla Administratorów platformy";
$langCombinedCourse = "Kurs z&#322;o&#380;ony";
$ToolIsNowVisible = "To narz&#281;dzie jest widoczne";
$ToolIsNowHidden = "To narz&#281;dzie jest niewodoczne";
$EditLink = "Edycja hiper&#322;&#261;cza";
$Blog_management = "Zarz&#261;dzanie blogami";
$Forum = "Fora";
$Course_maintenance = "Zarz&#261;dzanie kursem";
$TOOL_SURVEY = "Ankiety";
$GreyIcons = "Narz&#281;dzia";
$Interaction = "Tylko dla prowadz&#261;cych";
$Authoring = "Dost&#281;pne";
$Administration = "Administracyjne";
$IntroductionTextUpdated = "Tekst wprowadzaj&#261;cy zosta&#322; zaktualizowany";
$IntroductionTextDeleted = "Tekst wprowadzaj&#261;cy usuni&#281;ty";
$SessionIdentifier = "";
$SessionName = "";
$SessionCategory = "";
$SessionData = "";
?>