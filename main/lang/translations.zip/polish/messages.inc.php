<?php
/*
for more information: see languages.txt in the lang folder.
*/
$MessageEmptyMessageOrSubject = "";
$Inbox = "Skrzynka odbiorcza";
$Messages = "Wiadomo&#347;ci";
$SendMessage = "Wy&#347;lij wiadomo&#347;&#263;";
$NewMessage = "Nowa wiadomo&#347;&#263;";
$ComposeMessage = "Napisz wiadomo&#347;&#263;";
$DeleteSelectedMessages = "Usu&#324; wybrane wiadomo&#347;ci";
$SelectAll = "Zaznacz wszystko";
$DeselectAll = "Odznacz wszystko";
$ReplyToMessage = "Odpowiedz";
$BackToInbox = "Powrót do skrzynki odbiorczej";
$MessageSentTo = "Wiadomo&#347;&#263; zosta&#322;a wys&#322;ana do";
$SendMessageTo = "Wy&#347;lij do:";
$Myself = "Ja";
$From = "Od";
$To = "Do";
$Date = "Data";
$InvalidMessageId = "Numer identyfikacyjny wiadomo&#347;ci na któr&#261; chcesz odpowiedzie&#263; jest niepoprawny.";
$ErrorSendingMessage = "B&#322;&#261;d podczas próby wys&#322;ania wiadomo&#347;ci.";
$SureYouWantToDeleteSelectedMessages = "Czy na pewno chcesz skasowa&#263; zaznaczone wiadomo&#347;ci?";
$SelectedMessagesDeleted = "Zaznaczone wiadomo&#347;ci zosta&#322;y skasowane";
$EnterTitle = "Wpisz tytu&#322;";
$TypeYourMessage = "Wpisz tutaj wiadomo&#347;&#263;";
$MessageDeleted = "Wiadomo&#347;&#263; zosta&#322;a skasowana";
$ConfirmDeleteMessage = "Jeste&#347; pewny, &#380;e chcesz skasowa&#263; zaznaczone wiadomo&#347;ci ?";
$DeleteMessage = "Skasuj wiadomo&#347;&#263;";
$ReadMessage = "Czytaj wiadomo&#347;&#263;";
$SendInviteMessage = "";
$SendMessageInvitation = "";
$MessageTool = "";
$WriteAMessage = "";
$AlreadyReadMessage = "";
$UnReadMessage = "";
$MessageSent = "";
$YouShouldWriteAMessage = "";
?>