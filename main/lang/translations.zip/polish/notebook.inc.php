<?php
/*
for more information: see languages.txt in the lang folder.
*/
$NewNote = "Nowa notatka";
$Note = "Notatka";
$NoteDeleted = "Notatka usuni&#281;ta";
$NoteUpdated = "Notatka zaktualizowana";
$NoteCreated = "Utworzono notatk&#281;";
$YouMustWriteANote = "Wpisz notatk&#281;";
$SaveNote = "Zapisz notatk&#281;";
$WriteYourNoteHere = "Kliknij aby utworzy&#263; now&#261; notatk&#281;";
$SearchByTitle = "";
$WriteTheTitleHere = "";
$UpdateDate = "";
$NoteAddNew = "";
$OrderByCreationDate = "";
$OrderByModificationDate = "";
$OrderByTitle = "";
$NoteTitle = "";
$NoteComment = "";
$NoteAdded = "";
$NoteConfirmDelete = "";
$AddNote = "";
$ModifyNote = "";
$BackToNoteList = "";
$NotebookManagement = "";
$BackToNotesList = "";
$NotesSortedByTitleAsc = "";
$NotesSortedByTitleDESC = "";
$NotesSortedByUpdateDateAsc = "";
$NotesSortedByUpdateDateDESC = "";
$NotesSortedByCreationDateAsc = "";
$NotesSortedByCreationDateDESC = "";
?>