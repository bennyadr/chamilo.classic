<?php
/*
for more information: see languages.txt in the lang folder.
*/
$lang_new_item = "Nowy punkt zosta&#322; dodany";
$lang_title_notification = "Od ostatniej wizyty";
$lang_update_agenda = "Istniej&#261;cy porz&#261;dek dzienny zosta&#322; zaktualizowny";
$lang_new_agenda = "Punkt porz&#261;dku dziennego zosta&#322; dodany";
$lang_update_announcements = "Istniej&#261;ce og&#322;oszenia zosta&#322;y zaktualizowane";
$lang_new_announcements = "Nowe og&#322;oszenie zosta&#322;o dodane";
$lang_new_document = "Nowy dokumenty(y) zosta&#322;(y) dodane";
$lang_new_exercise = "Nowy test zosta&#322; dodany";
$lang_update_link = "Istniej&#261;cy odno&#347;nik zosta&#322; zaktualizowany";
$lang_new_link = "Nowy odno&#347;nik zosta&#322; dodany";
$lang_new_forum_topic = "Nowy temat zosta&#322; dodany";
$lang_new_groupforum_topic = "Nowy temat zosta&#322; dodany do Forum Grupy";
$lang_new_dropbox_file = "otrzymano nowy plik";
$lang_update_dropbox_file = "plik w Twojej skrzynce nadawczej zosta&#322; zaktualizowany";
$ForumCategoryAdded = "Kategoria forum zosta&#322;a dodana";
$LearnpathAdded = "&#346;cie&#380;ka nauki zosta&#322;a dodana";
$GlossaryAdded = "";
$QuizQuestionAdded = "";
$QuizQuestionUpdated = "";
$QuizQuestionDeleted = "";
$QuizUpdated = "";
$QuizAdded = "";
$QuizDeleted = "";
$DocumentInvisible = "";
$DocumentVisible = "";
$CourseDescriptionAdded = "";
$WikiAdded = "";
$SurveyAdded = "";
$NotebookAdded = "";
$NotebookUpdated = "";
$NotebookDeleted = "";
?>