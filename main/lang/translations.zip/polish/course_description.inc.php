<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langCourseProgram = "Opis kursu";
$langThisCourseDescriptionIsEmpty = "Ten kurs nie ma opisu";
$langEditCourseProgram = "Utwórz i edytuj z u&#380;yciem wzorca";
$QuestionPlan = "Pytania do prowadz&#261;cego";
$langInfo2Say = "Informacje dla studentów";
$langOuAutreTitre = "Tytu&#322;";
$langNewBloc = "Inne";
$langAddCat = "Dodaj kategori&#281;";
$langAdd = "Dodaj";
$langValid = "ZatwierdŒ";
$langBackAndForget = "Zrezygnuj";
$CourseDescriptionUpdated = "Opis kursu zosta&#322; uaktualniony";
$CourseDescriptionDeleted = "Opis kursu zosta&#322; usuni&#281;ty";
$CourseDescriptionIntro = "Aby utworzy&#263; opis kursu, kliknij na nag&#322;ówku i wype&#322;nij pole. <br><br>Nast&#281;pnie wybierz klawisz OK.";
$langSaveDescription = "Zapisz opis";
?>