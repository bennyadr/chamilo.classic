<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langPgTitle = "Tytu&#322; strony";
$langExplanation = "Strona musi by&#263; w formacie HTML (np. \\"my_page.htm\\"). Odno&#347;nik do strony umieszczone zostanie na Stronie g&#322;ównej. Je&#347;li chcesz wys&#322;a&#263; dokument inny ni&#380; HTML (PDF, Word, Power Point, Video, etc.) u&#380;yj <a href=../doc";
$langTooBig = "Nie wybrano &#380;adnego pliku do wys&#322;ania lub jest on za du&#380;y";
$langCouldNot = "Plik nie mo&#380;e by&#263; wys&#322;any";
$langNotAllowed = "Niedost&#281;pny";
$langAddPageToSite = "Dodaj stron&#281; do serwisu";
$langCouldNotSendPage = "Ten plik nie jest plikiem formatu HTML i nie mo&#380;e zosta&#263; wys&#322;any. Je&#347;li chcesz wys&#322;a&#263; dokument inny ni&#380; HTML (PDF, Word, Power Point, Video, etc.) u&#380;yj <a href=../document/document.php>narz&#281;dzia Dokumenty</a>";
$langSendPage = "Strona do wys&#322;ania";
$langPageTitleModified = "Tytu&#322; strony zosta&#322; zmodyfikowany";
$langPageAdded = "Strona dodana";
$langAddPage = "Dodaj stron&#281;";
$Choose = "";
?>