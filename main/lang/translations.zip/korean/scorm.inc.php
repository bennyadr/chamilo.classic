<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langScormVersion = "&#48260;&#51204;";
$langScormRestarted = "&#47784;&#46304; &#49688;&#50629;&#51012; &#49688;&#54665;&#54616;&#51648; &#47803;&#54616;&#50688;&#49845;&#45768;&#45796;.";
$langScormNoNext = "&#47560;&#51648;&#47561; &#47112;&#49832;&#51077;&#45768;&#45796;.";
$langScormNoPrev = "&#52395;&#48264;&#51704; &#47112;&#49832;&#51077;&#45768;&#45796;.";
$langScormTime = "&#49884;&#44036;";
$langScormNoOrder = "";
$langScormScore = "&#51216;&#49688;";
$langScormLessonTitle = "&#47112;&#49832; &#51228;&#47785;";
$langScormStatus = "&#51649;&#50948;";
$langScormToEnter = "&#46308;&#50612;&#44032;&#44592;";
$langScormFirstNeedTo = "&#52376;&#51020; &#47112;&#49832;&#51012; &#49688;&#54665;&#54616;&#49492;&#50556; &#54633;&#45768;&#45796;";
$langScormThisStatus = "&#51060; &#47112;&#49832;&#51008; &#51648;&#44552;";
$langScormClose = "";
$langScormRestart = "&#51116;&#49884;&#51089;";
$langScormCompstatus = "&#50756;&#47308;";
$langScormIncomplete = "&#48120;&#50756;&#47308;";
$langScormPassed = "&#54633;&#44201;";
$langScormFailed = "&#48520;&#54633;&#44201;";
$langScormPrevious = "&#51060;&#51204;";
$langScormNext = "&#45796;&#51020;";
$langScormTitle = "Chamilo Scorm player";
$langScormMystatus = "&#45236; &#49345;&#53468;";
$langScormNoItems = "&#51060; &#52968;&#53584;&#52768;&#50640;&#45716; &#50500;&#51060;&#53596;&#51060; &#50630;&#49845;&#45768;&#45796;.";
$langScormNoStatus = "&#51060; &#52968;&#53584;&#52768;&#51032; &#49345;&#53468;&#51221;&#48372;&#44032; &#50630;&#49845;&#45768;&#45796;";
$langScormLoggedout = "Scorm &#50640;&#49436; &#47196;&#44536;&#50500;&#50883;";
$langScormCloseWindow = "&#52285; &#45803;&#44592;";
$ScormBrowsed = "";
$langScormExitFullScreen = "&#51068;&#48152; &#54868;&#47732;&#51004;&#47196; &#46028;&#50500;&#44032;&#44592;";
$langScormFullScreen = "&#51204;&#52404; &#54868;&#47732;";
$langScormNotAttempted = "&#49884;&#46020;&#46104;&#51648; &#50506;&#50520;&#49845;&#45768;&#45796;";
$langCharset = "";
$langLocal = "";
$langRemote = "";
$langAutodetect = "";
$langAccomplishedStepsTotal = "";
$langUnknown = "";
$AreYouSureToDeleteSteps = "";
$Origin = "";
$Local = "";
$Remote = "";
$FileToUpload = "";
$ContentMaker = "";
$ContentProximity = "";
$UploadLocalFileFromGarbageDir = "";
$ThisItemIsNotExportable = "";
$MoveCurrentChapter = "";
$GenericScorm = "";
$UnknownPackageFormat = "";
$Attempt = "";
$MoveTheCurrentForum = "";
$WarningWhenEditingScorm = "";
$AdditionalProfileField = "";
?>