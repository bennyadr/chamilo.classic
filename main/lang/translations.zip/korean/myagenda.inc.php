<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langMyAgenda = "&#45236; &#51068;&#51221;";
$langToday = "&#50724;&#45720;";
?>