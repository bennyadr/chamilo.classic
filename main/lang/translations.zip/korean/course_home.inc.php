<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langActivate = "&#48372;&#50668;&#51452;&#44592;";
$langDeactivate = "&#49704;&#44608;";
$langInLnk = "&#49704;&#44608; &#46020;&#44396;&#50752; &#47553;&#53356;";
$langDelLk = "&#51221;&#47568;&#47196; &#51060; &#47553;&#53356;&#47484; &#49325;&#51228;&#54616;&#44192;&#49845;&#45768;&#44620;?";
$langCourseCreate = "&#44284;&#51221; &#50937;&#49324;&#51060;&#53944; &#49373;&#49457;";
$langNameOfTheLink = "&#47553;&#53356; &#47749;";
$lang_main_categories_list = "&#51452; &#52852;&#53580;&#53076;&#47532; &#47785;&#47197;";
$langCourseAdminOnly = "&#45812;&#45817;&#44368;&#49324;&#47564; &#44032;&#45733;";
$PlatformAdminOnly = "&#54540;&#47019;&#54268; &#44288;&#47532;&#51088;&#47564; &#44032;&#45733;";
$langCombinedCourse = "&#44208;&#54633;&#46108; &#44284;&#51221;";
$ToolIsNowVisible = "&#51060; &#46020;&#44396;&#44032; &#48372;&#50668;&#51665;&#45768;&#45796;";
$ToolIsNowHidden = "&#51060; &#46020;&#44396;&#44032; &#51060;&#51228; &#48372;&#50668;&#51665;&#45768;&#45796;";
$EditLink = "&#47553;&#53356; &#49688;&#51221;";
$Blog_management = "";
$Forum = "";
$Course_maintenance = "";
$TOOL_SURVEY = "";
$GreyIcons = "";
$Interaction = "";
$Authoring = "";
$Administration = "";
$IntroductionTextUpdated = "";
$IntroductionTextDeleted = "";
$SessionIdentifier = "";
$SessionName = "";
$SessionCategory = "";
$SessionData = "";
?>