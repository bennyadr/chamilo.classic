<?php
/*
for more information: see languages.txt in the lang folder.
*/
$langCourseProgram = "&#44284;&#51221; &#49444;&#47749;";
$langThisCourseDescriptionIsEmpty = "&#51060; &#44284;&#51221;&#50640; &#45824;&#54620; &#49444;&#47749;&#51060; &#51316;&#51116;&#54616;&#51648; &#50506;&#49845;&#45768;&#45796;.";
$langEditCourseProgram = "&#44284;&#51221; &#49444;&#47749; &#49373;&#49457;&#44284; &#49688;&#51221;";
$QuestionPlan = "&#44288;&#47532;&#51088;&#50640;&#44172; &#51656;&#47928;";
$langInfo2Say = "&#50976;&#51200;&#50640;&#44172; &#51228;&#44277;&#54616;&#45716; &#51221;&#48372;";
$langOuAutreTitre = "&#51228;&#47785;";
$langNewBloc = "&#44536; &#50808;";
$langAddCat = "&#52852;&#53580;&#44256;&#47532; &#52628;&#44032;";
$langAdd = "&#52628;&#44032;";
$langValid = "&#50976;&#54952;&#54632;";
$langBackAndForget = "back and forget";
$CourseDescriptionUpdated = "";
$CourseDescriptionDeleted = "";
$CourseDescriptionIntro = "";
$langSaveDescription = "";
?>